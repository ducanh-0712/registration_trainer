/* =============================================================================
   tests/smoke.test.js — plays every scenario start to finish by following the
   trainer's own hints, and fails if any run gets stuck or the page throws.

   Run:   npm install playwright   (once)
          node tests/smoke.test.js
   ========================================================================== */
'use strict';

const path = require('path');
const { chromium } = require('playwright');

const PAGE = 'file://' + path.resolve(__dirname, '..', 'index.html');
const SCENARIOS = ['clean', 'hold', 'closed', 'nocrn', 'prereq', 'waitlist', 'swap', 'gauntlet', 'planahead'];
const MAX_STEPS = 60;

/** Do whatever the current hint says. */
async function followHint(page, hint) {
  const target = page.locator(`[data-hint="${hint.key}"]`).first();
  if (!(await target.count())) throw new Error(`No element for hint "${hint.key}"`);

  if (hint.key === 'find-subj') {                 // Subject picker: type, then Enter picks it
    await page.fill('#f-subj', hint.val);
    await page.press('#f-subj', 'Enter');
    return;
  }
  const tag = await target.evaluate((el) => el.tagName + (el.type ? ':' + el.type : ''));
  if (tag.startsWith('SELECT')) await target.selectOption(hint.val);
  else if (tag === 'INPUT:checkbox') await target.click();
  else if (tag.startsWith('INPUT')) await target.fill(hint.val);
  else if (tag === 'LABEL') await target.locator('input').click();
  else await target.click();
}

async function playScenario(page, scenario) {
  await page.evaluate((s) => window.RegTrainer.start('guided', s, { startBeforeOpen: false, rush: false }), scenario);
  const steps = [];
  for (let i = 0; i < MAX_STEPS; i++) {
    const { done, hint } = await page.evaluate(() => ({ done: window.RegTrainer.state().done, hint: window.RegTrainer.hint() }));
    if (done) return steps;
    if (!hint || !hint.key) throw new Error(`Stuck with no clickable hint after: ${steps.join(' > ')}`);
    if (hint.wait) { await page.waitForTimeout(300); continue; }
    steps.push(hint.key + (hint.val ? '=' + hint.val : ''));
    await followHint(page, hint);
  }
  throw new Error(`Did not finish in ${MAX_STEPS} steps: ${steps.join(' > ')}`);
}

(async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1440, height: 800 } });
  const pageErrors = [];
  page.on('pageerror', (e) => pageErrors.push(e.message));

  // Skip the fake server delay so the test runs quickly.
  await page.addInitScript(() => { window.REG_TRAINER_NO_DELAY = true; });
  await page.goto(PAGE);

  let failed = 0;
  for (const scenario of SCENARIOS) {
    try {
      const steps = await playScenario(page, scenario);
      console.log(`PASS  ${scenario.padEnd(10)} ${steps.length} steps`);
    } catch (err) {
      failed++;
      console.log(`FAIL  ${scenario.padEnd(10)} ${err.message}`);
    }
  }
  if (pageErrors.length) {
    failed++;
    console.log('Page errors:\n  ' + pageErrors.join('\n  '));
  }
  await browser.close();
  console.log(failed ? `\n${failed} problem(s)` : '\nAll scenarios passed.');
  process.exit(failed ? 1 : 0);
})();
