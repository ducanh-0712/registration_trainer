/* =============================================================================
   actions.js — what each click does.

   Buttons carry data-act="name" (and sometimes data-v / data-crn / data-i).
   performAction() adds the fake server delay and a spinner, then calls
   handleAction(), which changes `state`; the page is then redrawn.
   ========================================================================== */
"use strict";

/* ---- Server delay -------------------------------------------------------------------- */

/** How long the fake server takes for this action, in ms (0 = instant). */
function delayFor(action) {
  // Tests set this flag to run without waiting.
  if (window.REG_TRAINER_NO_DELAY) return 0;
  const range = SERVER_DELAY_MS[action];
  if (!range) return 0;
  let ms = randomBetween(range);
  if (action === 'submit' && Math.abs(simNow() - TIME_TICKET_OPENS) < 60) ms += randomBetween(SUBMIT_RUSH_EXTRA_MS);
  return ms;
}

function showSpinner() {
  const bw = qs('#bw');
  if (!bw) return;
  const overlay = document.createElement('div');
  overlay.className = 'bw-busy';
  overlay.innerHTML = '<div class="bw-spin" role="status" aria-label="Loading"></div>';
  bw.appendChild(overlay);
}

/** Run an action after its server delay. Clicks during the delay are ignored, like a busy page. */
function performAction(action, el) {
  if (!state || state.done || state.busy) return;
  const ms = delayFor(action);
  if (!ms) {
    handleAction(action, el);
    if (state) renderRun();
    return;
  }
  state.busy = true;
  showSpinner();
  setTimeout(() => {
    if (!state) return;
    state.busy = false;
    handleAction(action, el);
    renderRun();
  }, ms);
}

/* ---- Navigation helpers ------------------------------------------------------------------ */

/**
 * Opening a Registration tile or landing link. Pages that can't register you
 * (Plan Ahead, Browse Classes, View Registration Information) count as a
 * mistake when opened during your window.
 */
function openRegistrationPage(page) {
  if (page === 'register') {
    Object.assign(state, { screen: 'term', termSel: '', termMode: 'register' });
  } else if (page === 'prep') {
    state.screen = 'prep';
    state.prep.stage = state.agreementAccepted ? 'status' : 'select';
  } else if (page === 'planahead') {
    Object.assign(state, { screen: 'term', termSel: '', termMode: 'plan' });
    if (state.scen !== 'planahead' && (state.mode === 'timed' || isOpen())) {
      mistake('Opened Plan Ahead during your window. It builds plans; it does not register you.');
    }
  } else {
    state.screen = page;
    if (state.mode === 'timed' || isOpen()) {
      mistake(`Opened ${{ browse: 'Browse Classes', info: 'View Registration Information' }[page]}. It does not register you.`);
    }
  }
}

/** Continue on Select a Term: checks the term, the agreement and the time ticket. */
function continueFromTerm() {
  if (!state.termSel) { notify('err', 'Select a term to continue.'); return; }
  if (state.termSel !== TERM.code) {
    notify('err', 'You are not permitted to register for this term.', [`Pick ${TERM.name}.`]);
    mistake('Picked the wrong term.');
    return;
  }
  if (state.termMode === 'plan') {
    state.screen = 'selplan';
    log('Opened Select A Plan');
    return;
  }
  if (!state.agreementAccepted) {
    notify('err', 'Registration is not available.', [`Your Financial Responsibility Agreement for ${TERM.name} has not been accepted. Complete it in Prepare for Registration.`]);
    if (!state.agreementErrorShown) {
      state.agreementErrorShown = true;
      state.errorsHit++;
      mistake('Went to register before accepting the Financial Responsibility Agreement.');
    }
    return;
  }
  if (!isOpen()) {
    state.earlyTries++;
    log('Continue clicked before window opened');
    notify('err', 'You may register during the following times:', [`${TERM.name}: ${TIME_TICKET_TEXT}`]);
    return;
  }
  // Like the real page, Register for Classes opens on Find Classes.
  Object.assign(state, { screen: 'register', tab: 'find', find: emptySearch() });
  log('Opened Register for Classes');
}

/* ---- Find Classes ------------------------------------------------------------------------- */

function runSearch() {
  const F = state.find;
  const subj = resolveSubject(F.subj) || F.subj.trim().toUpperCase();
  const num = F.num.trim();
  const kw = F.kw.trim().toLowerCase();
  Object.assign(F, { subj, open: false });
  if (!subj && !num && !kw) {
    F.err = true;
    notify('err', 'Enter at least one search field.');
    return;
  }
  F.err = false;
  F.results = state.sections
    .filter((s) => (!subj || s.subj === subj) && (!num || s.num === num) && (!kw || s.title.toLowerCase().includes(kw)))
    .map((s) => s.crn);
  log('Searched ' + [subj, num, kw].filter(Boolean).join(' '));
}

/* ---- Plans and CRNs ------------------------------------------------------------------------ */

/** Plans tab → Add All: every plan course that has a CRN goes to the Summary as Pending. */
function addAllFromPlan() {
  state.usedAddAll = true;
  let added = 0;
  state.plan.forEach((p) => {
    if (p.crn && !summaryRow(p.crn)) {
      state.summary.push({ crn: p.crn, status: 'pending', action: 'register', msg: '' });
      added++;
    }
  });
  log(`Add All moved ${added} section(s) to Summary`);
  const skipped = state.plan.filter((p) => !p.crn).length;
  if (skipped) notify('info', 'Some plan courses have no section', [`${skipped} course(s) need View Sections.`]);
}

/** Enter CRNs → Add to Summary. Clears the boxes only if something was added. */
function addTypedCrns() {
  let anyAdded = false;
  const unknown = [];
  state.crnInputs.forEach((crn) => {
    if (!crn) return;
    if (state.byCrn[crn]) { if (addToSummary(crn, 'Enter CRNs')) anyAdded = true; }
    else unknown.push(crn);
  });
  if (unknown.length) notify('err', 'CRN not found', unknown.map((c) => `${c} is not a valid CRN for ${TERM.name}.`));
  if (anyAdded) state.crnInputs = [''];
}

/* ---- Plan Ahead ------------------------------------------------------------------------------ */

/** Save Plan: the first save asks for a name; later saves just update. */
function savePlan() {
  const P = state.planAhead;
  if (!P.draft.length) { notify('err', 'Add at least one class before saving.'); return; }
  if (!P.saved) {
    Object.assign(P, { modal: true, nameVal: '' });
    return;
  }
  commitPlanDraft();
  notify('ok', 'Save Successful');
  if (planGoalMet()) finishRun();
}

/** Saving: drop rows marked Remove, and every remaining row becomes Planned. */
function commitPlanDraft() {
  const P = state.planAhead;
  P.draft = P.draft.filter((d) => d.action !== 'remove');
  P.draft.forEach((d) => { d.status = 'planned'; d.action = 'none'; });
}

/** Name Your Plan → Save (the first save of a new plan). */
function confirmPlanName() {
  const P = state.planAhead;
  const name = P.nameVal.trim();
  if (!name) { notify('err', 'Enter a plan name.'); return; }
  Object.assign(P, { name, saved: true, modal: false });
  commitPlanDraft();
  notify('ok', 'Save Successful');
  log(`Saved plan "${name}"`);

  const missing = state.plan.filter((p) => !P.draft.some((d) => courseKey(state.byCrn[d.crn]) === courseKey(p)));
  if (missing.length) {
    notify('info', 'Plan saved, but it is missing ' + missing.map(courseKey).join(', '), ['Search for it, add it, and click Save Plan again.']);
  }
  if (planGoalMet()) finishRun();
}

/* ---- The action table ------------------------------------------------------------------------ */

/**
 * Apply one click to `state`. `action` is the button's data-act; `el` is the
 * button, for its data-v / data-crn / data-i. Does not redraw (the caller does).
 */
function handleAction(action, el) {
  const v = el.dataset.v;
  const P = state.prep;

  switch (action) {
    // Navigation
    case 'go-landing':  state.screen = 'landing'; break;
    case 'go-term':     state.screen = 'term'; break;
    case 'go-selplan':  state.screen = 'selplan'; break;
    case 'tile':
    case 'link':        openRegistrationPage(v); break;
    case 'tile-other':  notify('info', 'Not part of this practice', ['Only the Registration tiles work here.']); break;
    case 'term-continue': continueFromTerm(); break;

    // Prepare for Registration
    case 'prep-continue':
      if (P.term !== TERM.code) { notify('err', `Select ${TERM.name} to continue.`); break; }
      Object.assign(P, { stage: 'status', tuitionModal: true });
      break;
    case 'tuition-continue': P.tuitionModal = false; break;
    case 'fra-accept':  Object.assign(P, { fraChecked: true, fraModal: false }); break;
    case 'fra-cancel':  Object.assign(P, { fraChecked: false, fraModal: false }); break;
    case 'fra-save':
      if (!P.fraChecked) { notify('err', 'Accept the Financial Responsibility Agreement before saving.'); break; }
      state.agreementAccepted = true;
      notify('ok', 'Save successful.');
      log('Accepted Financial Responsibility Agreement');
      break;
    case 'prep-done':   state.screen = 'landing'; break;

    // Layout
    case 'tab':         state.tab = v; break;
    case 'lowtab':      state.lowTab = v; break;
    case 'split':       state.split = v; break;
    case 'panels':      state.panelsMenu = !state.panelsMenu; break;
    case 'tip-x':       state.tipHidden = true; break;
    case 'plan-tog':    state.planOpen = !state.planOpen; break;

    // Find Classes
    case 'subj-clear':  Object.assign(state.find, { subj: '', open: false }); break;
    case 'subj-pick':   Object.assign(state.find, { subj: v, open: false }); break;
    case 'find-search': runSearch(); break;
    case 'find-again':  state.find.results = null; break;
    case 'find-clear':  state.find = emptySearch(); break;
    case 'adv':         notify('info', 'Advanced Search', ['Not part of this practice copy. Subject plus Course Number is the fast way.']); break;
    case 'add-sec':
      if (state.screen === 'planahead') {
        const crn = el.dataset.crn;
        if (!state.planAhead.draft.some((d) => d.crn === crn)) {
          state.planAhead.draft.push({ crn, status: 'pending', action: 'add' });
          log(`Added CRN ${crn} to the plan (Pending)`);
        }
      } else {
        addToSummary(el.dataset.crn, 'Find Classes');
      }
      break;

    // Class Details
    case 'details':       state.details = { crn: el.dataset.crn, tab: 'Class Details' }; break;
    case 'details-tab':   if (state.details) state.details.tab = v; break;
    case 'details-close': state.details = null; break;

    // Enter CRNs
    case 'crn-more':    state.crnInputs.push(''); break;
    case 'crn-add':     addTypedCrns(); break;

    // Plans tab
    case 'plan-addall': addAllFromPlan(); break;
    case 'plan-add':
      state.singleAdds++;
      addToSummary(el.dataset.crn, 'Plans (single Add)');
      break;
    case 'plan-view': {
      const p = state.plan[+el.dataset.i];
      state.tab = 'find';
      state.find = { ...emptySearch(), subj: p.subj, num: p.num, results: state.sections.filter((s) => courseKey(s) === courseKey(p)).map((s) => s.crn) };
      log('View Sections for ' + courseKey(p));
      break;
    }

    // Plan Ahead
    case 'create-plan':
      Object.assign(state, { screen: 'planahead', tab: 'find', find: emptySearch() });
      log('Created a new plan');
      break;
    case 'save-plan':   savePlan(); break;
    case 'plan-close':  state.planAhead.modal = false; break;
    case 'plan-save':   confirmPlanName(); break;

    // Submit
    case 'submit':      doSubmit(); break;
  }
}
