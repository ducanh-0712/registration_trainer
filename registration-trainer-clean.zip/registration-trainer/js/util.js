/* =============================================================================
   util.js — small, pure helpers used everywhere (DOM, text, time, courses).
   ========================================================================== */
"use strict";

/* ---- DOM ------------------------------------------------------------------- */

/** document.querySelector shorthand. */
const qs = (selector) => document.querySelector(selector);

/** Escape text before putting it inside an HTML template string. */
function escapeHtml(value) {
  const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value == null ? '' : value).replace(/[&<>"']/g, (c) => map[c]);
}

/** Build <option> tags from [value, label] pairs, marking `selected`. */
function optionsHtml(pairs, selected) {
  return pairs.map(([value, label]) =>
    `<option value="${value}"${value === selected ? ' selected' : ''}>${label}</option>`).join('');
}

/* ---- Randomness ------------------------------------------------------------ */

const randomInt = (n) => Math.floor(Math.random() * n);
const randomBetween = ([min, max]) => min + Math.random() * (max - min);

function shuffle(list) {
  const out = list.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = randomInt(i + 1);
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

/* ---- Time ------------------------------------------------------------------- */

/** "13:30" → 810 */
function toMinutes(hhmm) {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}

/** "13:30" → "01:30 PM" (the zero-padded style Banner uses for meeting times). */
function formatClassTime(hhmm) {
  let [h, m] = hhmm.split(':').map(Number);
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')} ${ampm}`;
}

/** Seconds after midnight → "6:59:50 AM". */
function formatClock(seconds) {
  seconds = Math.max(0, Math.floor(seconds));
  let h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')} ${ampm}`;
}

/** 12.34 → "0:12.3" */
function formatDuration(seconds) {
  seconds = Math.max(0, seconds);
  const m = Math.floor(seconds / 60);
  return m + ':' + (seconds - m * 60).toFixed(1).padStart(4, '0');
}

/* ---- Courses and sections ---------------------------------------------------- */

/** "CMSC 221" — identifies a course regardless of section. */
const courseKey = (s) => `${s.subj} ${s.num}`;

const unitsOf = (s) => parseFloat(s.units) || 0;

/** True when two meetings share a day and their times overlap. */
function overlaps(a, b) {
  if (!a || !b) return false;
  const shareDay = [...a.days].some((d) => b.days.includes(d));
  return shareDay && toMinutes(a.start) < toMinutes(b.end) && toMinutes(b.start) < toMinutes(a.end);
}

/** The S M T W T F S boxes in Meeting Times, with meeting days filled in. */
function daysHtml(days) {
  const letters = ['S', 'M', 'T', 'W', 'R', 'F', 'S'];
  const boxes = letters.map((x, i) => {
    const on = i > 0 && i < 6 && days.includes(x);
    return `<i class="${on ? 'on' : ''}">${x === 'R' ? 'T' : x}</i>`;
  }).join('');
  return `<span class="days" aria-label="${escapeHtml(days)}">${boxes}</span>`;
}

/** Subject code → display name, e.g. CMSC → Computer Science. */
const subjectName = (code) => SUBJECT_NAMES[code] || code;
