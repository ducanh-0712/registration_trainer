/* =============================================================================
   hints.js — works out the next correct click from the current state.

   nextHint() returns { key, text, why?, val?, wait? }:
     key   matches a data-hint="…" attribute on the element to click
     val   the value to type or select, when the step is an input
     wait  true while the right move is to wait for 7:00
   The hint box (Guided mode, or the Hint button) and the automated test in
   tests/ both follow these hints.
   ========================================================================== */
"use strict";

/** An open section of `key` that doesn't clash with your other classes. Your planned section first. */
function bestSection(key) {
  const busy = activeRows().map((r) => state.byCrn[r.crn]).filter((s) => courseKey(s) !== key);
  const rank = { plan: 0, alt: 1, conflict: 2 };
  return state.sections
    .filter((s) => courseKey(s) === key && seatsLeft(s) > 0 && !busy.some((o) => overlaps(o, s)))
    .sort((a, b) => rank[a.kind] - rank[b.kind])[0] || null;
}

/** Steps to search Find Classes for `key` and add `crn`. */
function searchSteps(key, crn, why, againLabel = 'Search Again') {
  const [subj, num] = key.split(' ');
  if (state.screen === 'register' && state.tab !== 'find') {
    return { key: 'tab-find', text: `Open the Find Classes tab to look for another section of ${key}.`, why };
  }
  const results = state.find.results;
  const showing = results && results.some((c) => courseKey(state.byCrn[c]) === key);
  if (!showing) {
    if (results) return { key: 'find-again', text: `Click ${againLabel} to start a new search.`, why };
    if (resolveSubject(state.find.subj) !== subj) return { key: 'find-subj', val: subj, text: `Pick ${subjectName(subj)} in Subject.`, why };
    if (state.find.num.trim() !== num) return { key: 'find-num', val: num, text: `Type ${num} in Course Number.`, why };
    return { key: 'find-search', text: 'Click Search.', why };
  }
  return { key: 'add-' + crn, text: `Click Add on CRN ${crn}. It has open seats and does not overlap your other classes.`, why };
}

function nextHint() {
  if (!state || state.done) return null;
  const s = state.screen;
  const buildingPlan = state.scen === 'planahead';

  if (s === 'home') {
    if (buildingPlan) return { key: 'tile-planahead', text: 'Scroll to the Registration section and click Plan Ahead.' };
    if (!state.agreementAccepted) return { key: 'tile-prep', text: 'Scroll to the Registration section and click Prepare for Registration.', why: 'Your Financial Responsibility Agreement for Spring 2027 is not accepted yet, so registration will refuse you.' };
    return { key: 'tile-register', text: 'Scroll to the Registration section and click Register for Classes.' };
  }

  if (s === 'landing') {
    if (buildingPlan) return { key: 'link-planahead', text: 'Click Plan Ahead.' };
    if (!state.agreementAccepted) return { key: 'link-prep', text: 'Open Prepare for Registration first.', why: 'Your Financial Responsibility Agreement for Spring 2027 is not accepted yet, so registration will refuse you.' };
    return { key: 'link-register', text: 'Click Register for Classes.', why: 'Plan Ahead and Browse Classes only look things up. Register for Classes is where adding and submitting happens.' };
  }

  if (s === 'selplan') return { key: 'create-plan', text: 'Click Create a New Plan.', why: 'You can keep up to three plans for each term.' };
  if (s === 'planahead' && buildingPlan) return planAheadHint();
  if (['planahead', 'browse', 'info'].includes(s)) {
    return { key: 'crumb-registration', text: 'This page does not register you. Click Registration in the breadcrumb to go back.' };
  }
  if (s === 'prep') return prepHint();

  if (s === 'term') {
    if (state.termSel !== TERM.code) return { key: 'term-select', val: TERM.code, text: 'Select Spring 2027 in Terms Open for Registration.' };
    if (state.termMode === 'plan') return { key: 'term-continue', text: 'Click Continue.', why: 'Plan Ahead is open any time. You do not need your time ticket to build a plan.' };
    if (!isOpen()) return { key: 'term-continue', text: 'Your time ticket starts at 7:00:00 AM. Watch the clock, then click Continue the moment it opens.', why: 'It will not open early.', wait: true };
    return { key: 'term-continue', text: 'Click Continue.' };
  }

  if (s === 'register') return registerHint();
  return null;
}

function planAheadHint() {
  const P = state.planAhead;
  if (P.modal) {
    if (!P.nameVal.trim()) return { key: 'plan-name', val: 'Spring 2027 Plan 1', text: 'Type a plan name, like Spring 2027 Plan 1.' };
    return { key: 'plan-save', text: 'Click Save.' };
  }
  const missing = state.plan.filter((p) => !P.draft.some((d) => courseKey(state.byCrn[d.crn]) === courseKey(p)));
  if (missing.length) {
    const p = missing[0];
    const crn = p.crn || p.baseCrn;
    const step = searchSteps(courseKey(p), crn, undefined, 'Catalog Search Results');
    if (step.key === 'add-' + crn) {
      return { key: step.key, text: `Click Add on CRN ${crn} (section ${state.byCrn[crn].sec}).`, why: 'Add the exact section, so your plan has a CRN and Add All works on registration day.' };
    }
    return step;
  }
  return { key: 'save-plan', text: 'Everything is in your plan as Pending. Click Save Plan.', why: 'Nothing is kept until you save. Status changes from Pending to Planned.' };
}

function prepHint() {
  const P = state.prep;
  if (state.agreementAccepted) return { key: 'prep-done', text: 'Agreement saved. Click Continue to go back to Registration.' };
  if (P.stage === 'select') {
    if (P.term !== TERM.code) return { key: 'prep-term', val: TERM.code, text: 'Select Spring 2027.' };
    return { key: 'prep-continue', text: 'Click Continue.' };
  }
  if (P.tuitionModal) return { key: 'tuition-continue', text: 'Click CONTINUE to acknowledge tuition.' };
  if (P.fraModal) return { key: 'fra-accept', text: 'Read the terms, then click I Accept.' };
  if (!P.fraChecked) return { key: 'fra-check', text: 'Check the Financial Responsibility Agreement box.' };
  return { key: 'fra-save', text: 'Click SAVE. Nothing counts until it saves.' };
}

function registerHint() {
  const { summary, byCrn, targets, plan } = state;

  // A full section with waitlist seats: switch its Action to Wait List.
  for (const r of summary.filter((x) => x.status === 'error' || x.status === 'pending')) {
    const s = byCrn[r.crn];
    if ((r.wl || canWaitlist(s)) && targets.wait !== undefined && courseKey(s) === courseKey(plan[targets.wait]) && r.action !== 'waitlist') {
      return { key: 'act-' + r.crn, val: 'waitlist', text: `CRN ${r.crn} is full but has waitlist seats. Change its Action to Wait List.`, why: 'Then Submit. Waitlisting is not registration, so watch your Richmond email for a seat offer.' };
    }
  }

  // Errors marked Remove: clear prerequisite errors, replace closed or clashing sections.
  const failedRows = summary.filter((r) => r.status === 'error' && r.action === 'remove');
  const prereqRow = failedRows.find((r) => byCrn[r.crn].prereq);
  if (prereqRow) {
    return { key: 'submit', text: `${courseKey(byCrn[prereqRow.crn])} failed: Must have the required prerequisite(s). Its Action is already Remove. Click Submit to clear it.`, why: 'Another section will not fix this. After registration, ask the department or instructor for an override.' };
  }
  for (const r of failedRows) {
    const key = courseKey(byCrn[r.crn]);
    const replaced = summary.some((x) => x !== r && courseKey(byCrn[x.crn]) === key && x.status !== 'error' && x.status !== 'dropped');
    if (replaced) continue;
    const best = bestSection(key);
    if (best) return searchSteps(key, best.crn, `CRN ${r.crn} failed (${r.msg}). Its Action is already Remove, so the next Submit clears it.`);
  }

  // Section swap: add the new CRN, drop the old one, turn on Conditional Add and Drop.
  if (state.scen === 'swap') {
    const fresh = targets.swapNew;
    const old = targets.swapOld;
    if (!summaryRow(fresh)) {
      if (state.tab !== 'crn') return { key: 'tab-crn', text: 'Open the Enter CRNs tab.', why: 'Fastest way to add a section you already know.' };
      if (!state.crnInputs.includes(fresh)) {
        const i = Math.max(0, state.crnInputs.findIndex((x) => !x));
        return { key: 'crn-input-' + i, val: fresh, text: `Type CRN ${fresh}.` };
      }
      return { key: 'crn-add', text: 'Click Add to Summary.' };
    }
    const o = summaryRow(old);
    if (o && o.status === 'registered' && o.action !== 'drop') return { key: 'act-' + old, val: 'drop', text: `In Summary, set the Action for CRN ${old} to Drop/No Refund.` };
    if (!state.cond) return { key: 'cond', text: 'Check Conditional Add and Drop.', why: 'The drop then only happens if the new section actually registers.' };
    return { key: 'submit', text: 'Click Submit.' };
  }

  const inSummary = (key) => summary.some((r) => courseKey(byCrn[r.crn]) === key && r.status !== 'error' && r.status !== 'dropped');

  // Planned section filled up after it failed once: find another.
  const lost = plan.filter((p) => p.crn && !inSummary(courseKey(p)) && !summaryRow(p.crn) && state.failed.has(p.crn) && seatsLeft(byCrn[p.crn]) <= 0);
  for (const p of lost) {
    const best = bestSection(courseKey(p));
    if (best) return searchSteps(courseKey(p), best.crn, `Your planned section ${p.crn} is full now. Adding it again will only fail.`);
    return { key: '', text: `No open section of ${courseKey(p)} fits your schedule. Register the rest now, then talk to your advisor about a substitute.` };
  }

  // Load the plan.
  const notLoaded = plan.filter((p) => p.crn && !inSummary(courseKey(p)) && !summaryRow(p.crn) && !(byCrn[p.crn].prereq && state.failed.has(p.crn)));
  if (notLoaded.length) {
    if (state.tab !== 'plans') return { key: 'tab-plans', text: 'Open the Plans tab.', why: 'Your saved plan lives here. Loading it is one click.' };
    return { key: 'add-all', text: 'Click Add All.', why: 'It moves every section in your plan to the Summary as Pending.' };
  }

  // Courses saved without a section.
  const noSection = plan.filter((p) => !p.crn && !inSummary(courseKey(p)));
  if (noSection.length) {
    const p = noSection[0];
    if (state.tab === 'plans') return { key: 'view-' + p.idx, text: `${courseKey(p)} was saved without a section, so Add All skipped it. Click View Sections.`, why: 'Lesson: save CRNs into your plan ahead of time.' };
    const best = bestSection(courseKey(p));
    if (best) return searchSteps(courseKey(p), best.crn, 'Pick the section that fits around your other classes.');
    return { key: '', text: `No open section of ${courseKey(p)} fits your schedule right now.` };
  }

  if (hasChanges()) return { key: 'submit', text: 'Click Submit.', why: 'Pending means nothing is registered yet. Only Submit sends it.' };
  return { key: '', text: 'Check the Summary: every plan course should say Registered.' };
}
