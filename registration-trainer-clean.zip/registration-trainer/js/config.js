/* =============================================================================
   config.js — everything you might want to change lives here.

   The trainer never reads anything from BannerWeb. All course data below is
   typed in by hand; edit MY_PLAN when your plan changes.
   ========================================================================== */
"use strict";

/* ---- Term and time ticket ------------------------------------------------ */

const TERM = { code: '202710', name: 'Spring 2027' };

/** Registration opens at this many seconds after midnight (7:00:00 AM). */
const TIME_TICKET_OPENS = 7 * 3600;

/** Shown in the "You may register during the following times" message. */
const TIME_TICKET_TEXT = '11/12/2026 07:00 AM to 11/13/2026 02:00 PM';

/** Max units per term. The Registrar's guide shows "Max: 5.5" in the Summary. */
const MAX_HOURS = 5.5;

/** How your name appears in the top-right of the page. */
const STUDENT_NAME = 'Nguyen, Anh';

/* ---- Your plan ------------------------------------------------------------
   Copied from Plan Ahead. `crn` can be left '' for a course saved without a
   section; Add All will then skip it, exactly like the real page.
   Days use M T W R F (R = Thursday). Times are 24-hour.
   NOTE: only PHIL 120's time is confirmed; the other three are placeholders. */

const PLAN_NAME = 'Plan B';

const MY_PLAN = [
  { subj: 'PHIL', num: '120', sec: '01', crn: '23642', title: 'Contemporary',        days: 'TR',  start: '09:00', end: '10:15', units: '1', instr: 'Staff' },
  { subj: 'CMSC', num: '221', sec: '01', crn: '20122', title: 'Data Structures',     days: 'MWF', start: '10:30', end: '11:20', units: '1', instr: 'Staff' },
  { subj: 'CMSC', num: '222', sec: '01', crn: '22658', title: 'Discrete Structures', days: 'MWF', start: '12:00', end: '12:50', units: '1', instr: 'Staff' },
  { subj: 'MATH', num: '300', sec: '01', crn: '23892', title: 'Fundamentals',        days: 'TR',  start: '13:30', end: '14:45', units: '1', instr: 'Staff' },
];

/* ---- What the Start button launches --------------------------------------
   mode:            'timed' (no hints unless you ask) or 'guided' (hint box always on)
   scenario:        any key of SCENARIOS below, or 'random'
   startBeforeOpen: begin 10 seconds before 7:00 so you practise waiting
   rush:            another planned section fills at 7:00:45 if you are slow   */

const START = { mode: 'timed', scenario: 'clean', startBeforeOpen: true, rush: false };

/* ---- Practice scenarios --------------------------------------------------
   target = seconds from 7:00:00 to "everything registered" for a Ready grade. */

const SCENARIOS = {
  clean:     { name: 'Clean load',          target: 20,  brief: 'Your time ticket opens at 7:00:00 AM. Load your whole plan and register it.' },
  hold:      { name: 'Agreement not done',  target: 45,  brief: 'You never accepted the Financial Responsibility Agreement for Spring 2027. Registration will block you until you do.' },
  closed:    { name: 'Section closed',      target: 45,  brief: 'One of your planned sections is full by the time you submit. Replace it with an open section that fits your schedule.' },
  nocrn:     { name: 'Plan missing a CRN',  target: 30,  brief: 'One course was saved to your plan without a section. Add All will skip it.' },
  waitlist:  { name: 'Waitlist',            target: 30,  brief: 'Open registration, waitlists active. One section is full but has a waitlist. Register the rest and get on that waitlist.' },
  swap:      { name: 'Section swap',        target: 30,  brief: 'You are already registered. Switch one course to a different section without risking your seat.' },
  gauntlet:  { name: 'Gauntlet',            target: 90,  brief: 'Agreement not accepted, a planned section closes, and one course has no CRN. All at once.' },
  prereq:    { name: 'Prerequisite error',  target: 30,  brief: 'One course in your plan will come back with a prerequisite error. Register everything else and clear the error.' },
  planahead: { name: 'Build your plan',     target: 120, brief: 'Before your window: use Plan Ahead to search for each of your courses, add the exact CRNs, and save the plan with a name.' },
};

/** Pool that 'random' picks from (repeats make those more likely). */
const RANDOM_POOL = ['clean', 'hold', 'closed', 'nocrn', 'closed', 'nocrn', 'hold', 'gauntlet'];

/* ---- Server delay ----------------------------------------------------------
   [min, max] milliseconds the fake server takes to answer each action.
   These are guesses, not measurements. Submit gets an extra 1–2.5 s in the
   first minute after 7:00 when everyone is clicking at once. */

const SERVER_DELAY_MS = {
  tab: [150, 350],            lowtab: [100, 250],
  link: [700, 1400],          tile: [800, 1500],
  'go-landing': [600, 1200],  'go-term': [600, 1200],    'go-selplan': [600, 1100],
  'term-continue': [900, 1800],
  'prep-continue': [700, 1300], 'fra-save': [600, 1100], 'prep-done': [600, 1200],
  'create-plan': [700, 1300],
  'find-search': [700, 1400], 'find-again': [200, 450],
  'add-sec': [300, 700],      'plan-addall': [500, 1000], 'plan-add': [300, 700], 'plan-view': [600, 1200],
  'crn-add': [400, 900],
  submit: [1500, 3000],
  'save-plan': [300, 600],    'plan-save': [700, 1300],
  details: [400, 900],
};
const SUBMIT_RUSH_EXTRA_MS = [1000, 2500];

/* ---- Course catalogue helpers -------------------------------------------- */

/** Subject codes → names shown in the Subject picker and search results. */
const SUBJECT_NAMES = {
  ACCT: 'Accounting', ANTH: 'Anthropology', ART: 'Art', BIOL: 'Biology', BUAD: 'Business Administration',
  CHEM: 'Chemistry', CHIN: 'Chinese', CLSC: 'Classical Studies', CMSC: 'Computer Science', DSCI: 'Data Science',
  ECON: 'Economics', ENGL: 'English', ENVR: 'Environmental Studies', FIN: 'Finance', FREN: 'French',
  FYS: 'First-Year Seminar', GEOG: 'Geography', GERM: 'German', HIST: 'History', JOUR: 'Journalism',
  LDST: 'Leadership Studies', MATH: 'Mathematics', MGMT: 'Management', MKT: 'Marketing', MUS: 'Music',
  PHIL: 'Philosophy', PHYS: 'Physics', PLSC: 'Political Science', PSYC: 'Psychology', RELG: 'Religious Studies',
  RHCS: 'Rhetoric & Communication', SOC: 'Sociology', SPAN: 'Spanish', STAT: 'Statistics', THTR: 'Theatre',
  WELL: 'Wellness',
};

/** Typical meeting slots, used to invent the extra sections of each course. */
const TIME_SLOTS = {
  MWF: [['08:00', '08:50'], ['09:00', '09:50'], ['10:30', '11:20'], ['12:00', '12:50'], ['13:30', '14:20'], ['15:00', '15:50']],
  TR:  [['09:00', '10:15'], ['10:30', '11:45'], ['12:00', '13:15'], ['13:30', '14:45'], ['15:00', '16:15'], ['16:30', '17:45']],
};

/* ---- Layout ------------------------------------------------------------------
   The replica is laid out at a fixed design width (measured from real
   screenshots) and zoomed to fill the window, so proportions always match. */

const BANNER_DESIGN_WIDTH = 1674;
const TASKBAR_HEIGHT = 34;

/* ---- Storage ----------------------------------------------------------------- */

const STORAGE_KEYS = { history: 'regtrainer.history.v1' };
const HISTORY_LIMIT = 40;
