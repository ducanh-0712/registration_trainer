/* =============================================================================
   main.js — boot. Loaded last, after everything it calls is defined.
   ========================================================================== */
"use strict";

/**
 * Small hook for the automated test in tests/ (and for poking around in the
 * browser console). Not used by the trainer itself.
 */
window.RegTrainer = {
  hint: () => nextHint(),
  state: () => state,
  start: (mode, scenario, opts) => startRun(mode, scenario, opts || { startBeforeOpen: false, rush: false }),
};

render();
