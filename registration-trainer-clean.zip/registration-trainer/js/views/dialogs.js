/* =============================================================================
   views/dialogs.js — pop-up windows drawn inside the page:
     • Tuition Acknowledgement and Financial Responsibility Agreement
       (Prepare for Registration, from UR's older screenshot guide)
     • Class Details (click any course title)
     • Name Your Plan (Plan Ahead → Save Plan)
   ========================================================================== */
"use strict";

function prepDialogHtml() {
  if (state.screen !== 'prep') return '';
  const P = state.prep;

  if (P.tuitionModal) {
    return `
      <div class="bw-modal-bg"><div class="bw-modal" role="dialog" aria-label="Tuition acknowledgement">
        <div class="mh">Tuition Acknowledgement</div>
        <div class="mb">Registering for ${TERM.name} classes creates tuition and fee charges on your student account. Continue to review the Financial Responsibility Agreement.</div>
        <div class="mf"><button class="bw-btn" data-act="tuition-continue" data-hint="tuition-continue">CONTINUE</button></div>
      </div></div>`;
  }
  if (P.fraModal) {
    return `
      <div class="bw-modal-bg"><div class="bw-modal" role="dialog" aria-label="Financial Responsibility Agreement">
        <div class="mh">Financial Responsibility Agreement</div>
        <div class="mb">
          <p>When I register for any class, I accept full responsibility to pay all tuition, fees and other associated costs assessed as a result of my registration.</p>
          <p>I understand that dropping classes after the published deadlines may not reduce what I owe.</p>
          <p>(Practice text. Read the real agreement when you sign it.)</p>
        </div>
        <div class="mf">
          <button class="bw-btn sec" data-act="fra-cancel">Cancel</button>
          <button class="bw-btn" data-act="fra-accept" data-hint="fra-accept">I Accept</button>
        </div>
      </div></div>`;
  }
  return '';
}

/* ---- Class Details ---------------------------------------------------------------------- */

const CLASS_DETAIL_SECTIONS = [
  'Class Details', 'Bookstore Links', 'Course Description', 'Syllabus', 'Attributes', 'Restrictions',
  'Instructor/Meeting Times', 'Enrollment/Waitlist', 'Corequisites', 'Prerequisites', 'Mutual Exclusion',
  'Cross Listed Courses', 'Linked Sections', 'Fees', 'Catalog',
];

/** Body text for one section of Class Details. Only the useful ones are filled in. */
function classDetailBody(s, section) {
  const defs = (pairs) => '<dl class="cd">' + pairs.map(([k, v]) => `<dt>${k}:</dt><dd>${v}</dd>`).join('') + '</dl>';
  switch (section) {
    case 'Class Details':
      return defs([
        ['Associated Term', TERM.name], ['CRN', s.crn], ['Campus', 'Main'], ['Schedule Type', 'Lecture'],
        ['Instructional Method', 'Traditional'], ['Section Number', escapeHtml(s.sec)], ['Subject', escapeHtml(subjectName(s.subj))],
        ['Course Number', escapeHtml(s.num)], ['Title', escapeHtml(s.title.toUpperCase())], ['Credit Hours', s.units],
        ['Grade Mode', 'Standard Grading Mode'],
      ]);
    case 'Instructor/Meeting Times':
      return `<p><b>Instructor:</b> ${escapeHtml(s.instr)} (Primary)</p><p>${daysHtml(s.days)} ${formatClassTime(s.start)} - ${formatClassTime(s.end)}<br>Type: Class</p>`;
    case 'Enrollment/Waitlist':
      return defs([
        ['Enrollment Actual', s.enrolled], ['Enrollment Maximum', s.cap], ['Enrollment Seats Available', Math.max(0, seatsLeft(s))],
        ['Waitlist Capacity', s.waitCap], ['Waitlist Actual', s.waitCount], ['Waitlist Seats Available', Math.max(0, s.waitCap - s.waitCount)],
      ]);
    case 'Restrictions':
      return '<p><span class="ic ok inline">✓</span> Not all restrictions are applicable.</p><p>Practice copy: check the real class details for actual restrictions.</p>';
    default:
      return '<p>No information available in this practice copy.</p>';
  }
}

function classDetailsHtml() {
  if (!state.details) return '';
  const s = state.byCrn[state.details.crn];
  if (!s) return '';
  const current = state.details.tab || 'Class Details';
  const nav = CLASS_DETAIL_SECTIONS.map((n) =>
    `<button data-act="details-tab" data-v="${n}" class="${n === current ? 'on' : ''}">${n}</button>`).join('');

  return `
    <div class="bw-modal-bg top"><div class="cd-modal" role="dialog" aria-label="Class Details">
      <div class="cd-h">Class Details for ${escapeHtml(s.title.toUpperCase())} ${escapeHtml(subjectName(s.subj))} ${escapeHtml(s.num)} ${escapeHtml(s.sec)}
        <button class="cd-x" data-act="details-close" aria-label="Close">×</button></div>
      <div class="cd-sub"><b>Term:</b> ${TERM.code} | <b>CRN:</b> ${s.crn}</div>
      <div class="cd-body"><nav class="cd-nav">${nav}</nav><div class="cd-main">${classDetailBody(s, current)}</div></div>
      <div class="cd-f"><button class="bw-btn gray" data-act="details-close">Close</button></div>
    </div></div>`;
}

/* ---- Name Your Plan ------------------------------------------------------------------------ */

function namePlanDialogHtml() {
  if (state.screen !== 'planahead' || !state.planAhead.modal) return '';
  return `
    <div class="bw-modal-bg"><div class="np-modal" role="dialog" aria-label="Name Your Plan">
      <div class="np-h">Name Your Plan<button class="cd-x" data-act="plan-close" aria-label="Close">×</button></div>
      <div class="np-b"><label for="plan-name">Plan Name</label><input id="plan-name" class="bw-in" data-pa-name="1" data-hint="plan-name" value="${escapeHtml(state.planAhead.nameVal)}"></div>
      <div class="np-f">
        <button class="bw-btn cont small" data-act="plan-close">Close</button>
        <button class="bw-btn cont small" data-act="plan-save" data-hint="plan-save">Save</button>
      </div>
    </div></div>`;
}
