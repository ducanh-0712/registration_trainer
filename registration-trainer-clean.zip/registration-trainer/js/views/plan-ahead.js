/* =============================================================================
   views/plan-ahead.js — Plan Ahead (the "Build your plan" drill).

   Follows guide pages 5–7: search, Add each section (it appears Pending in the
   plan panel), Save Plan → name it → everything turns Planned.
   ========================================================================== */
"use strict";

const PLAN_PANEL_ICON = '<svg viewBox="0 0 16 16" width="17" height="17"><path d="M2 3h12v11H2z" fill="none" stroke="#444" stroke-width="1.5"/><path d="M5 1v3M11 1v3M2 6h12" stroke="#444" stroke-width="1.5"/></svg>';

function planAheadHtml() {
  const P = state.panels;
  const showUpper = P.upper && state.split !== 'up';
  const showLower = state.split !== 'down' && (P.sched || P.summary);

  // Plan Ahead only has the Find Classes tab.
  const upper = showUpper
    ? `<div class="bw-tabs"><button class="bw-tab" aria-selected="true" data-act="tab" data-v="find">Find Classes</button></div>${framedHtml(findClassesHtml())}`
    : '';
  const lower = showLower
    ? `<div class="bw-lower">${P.sched ? schedulePanelHtml(true) : ''}${P.summary ? planPanelHtml() : ''}</div>`
    : '';
  return upper + splitterHtml() + lower;
}

/** Lower-right panel: the plan being built. */
function planPanelHtml() {
  const pa = state.planAhead;
  const title = pa.saved ? escapeHtml(pa.name) : TERM.name + 'Untitled Plan'; // the real page omits the space
  const plannedHours = pa.draft.filter((d) => d.status === 'planned').reduce((sum, d) => sum + unitsOf(state.byCrn[d.crn]), 0);

  const rows = pa.draft.map((d) => {
    const s = state.byCrn[d.crn];
    const pending = d.status === 'pending';
    const actions = pending ? [['add', 'Add'], ['remove', 'Remove']] : [['none', 'None'], ['remove', 'Remove']];
    return `<tr>
      <td class="ttl"><button class="tlink${pending ? ' italic' : ''}" data-act="details" data-crn="${s.crn}">${escapeHtml(s.title)}</button></td>
      <td>${escapeHtml(courseKey(s))}, ${escapeHtml(s.sec)}</td><td>${s.units}</td><td>${s.crn}</td><td>Lecture</td>
      <td><span class="note-ico"></span></td>
      <td><span class="pill-st ${pending ? 'pend' : 'plan'}">${pending ? 'Pending' : 'Planned'}</span></td>
      <td><span class="selwrap act"><select data-chg="pa-act" data-crn="${s.crn}" aria-label="Action for CRN ${s.crn}">${optionsHtml(actions, d.action)}</select><i></i></span></td>
    </tr>`;
  }).join('');

  const widths = [22, 14, 6, 9, 10, 7, 13, 19];
  const table = pa.draft.length ? `
    <table class="sm" style="min-width:640px">
      <colgroup>${widths.map((w) => `<col style="width:${w}%">`).join('')}</colgroup>
      <thead><tr><th>Title</th><th>Details</th><th>Hours</th><th>CRN</th><th>Schedule Type</th><th>Note</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>` : '';

  return `
    <div class="lp">
      <div class="plan-h">${PLAN_PANEL_ICON}<b>${title}</b><span class="note-ico"></span>${pa.saved ? '<span class="plan-pref">Preferred</span>' : ''}</div>
      <div class="sum-scroll">${table}</div>
      <div class="sum-tot"><b>Total Planned Hours:</b>&nbsp;${plannedHours}</div>
    </div>`;
}

function planAheadFooterHtml() {
  return `
    <div class="bw-foot">
      ${panelsMenuHtml(['Find Classes', 'Schedule', 'Plan'])}
      <button class="panels-btn" data-act="panels" aria-expanded="${state.panelsMenu}">Panels ▾</button>
      <div class="rt"><button class="bw-btn dark" data-act="save-plan" data-hint="save-plan">Save Plan</button></div>
    </div>`;
}
