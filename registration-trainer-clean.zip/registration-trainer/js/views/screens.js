/* =============================================================================
   views/screens.js — the simpler pages: Banner home (tiles), Registration
   landing, Select a Term, Prepare for Registration, View Registration
   Information, Select A Plan, and the "this page doesn't register you" page.
   ========================================================================== */
"use strict";

/* ---- Banner home: Students tiles and Registration tiles ------------------------------ */

const TILE_ICON = '<svg viewBox="0 0 40 40" width="40" height="40"><rect x="9" y="7" width="22" height="28" rx="2" fill="#fff" stroke="#6b8fc7" stroke-width="1.6"/><rect x="13" y="13" width="14" height="2" fill="#9fb6dd"/><rect x="13" y="18" width="14" height="2" fill="#9fb6dd"/><rect x="13" y="23" width="10" height="2" fill="#9fb6dd"/><circle cx="31" cy="9" r="5" fill="#2b7de0"/><rect x="30.2" y="6.5" width="1.6" height="4" fill="#fff"/></svg>';

/** Student tiles are shown for realism; only Registration tiles do anything. */
const STUDENT_TILES = [
  ['Student Profile', 'View detailed student information including biographical, curriculum, etc.'],
  ['Academic Transcripts', 'Display Transcripts.'],
  ['Direct Deposit', 'Create, view and update your direct deposit allocation(s).'],
  ['Enrollment Verifications', 'Links to National Student Clearinghouse for verifications.'],
  ['FERPA Waiver Form', 'Complete waiver form.'],
  ['Grades', 'View grades by term and level, or across terms, or across levels.'],
  ['GradTracker Login', 'View degree evaluations.'],
  ['Graduation Application', 'Apply to graduate.'],
  ['Informed Consent', 'Complete consent/release for off-campus experiences.'],
  ['Pay Tuition and Fees', 'View current/previous invoice, review account status and setup a payment plan.'],
  ['Personal Information', 'View and update your biographical and demographic information.'],
  ['Tax Notification (1098-T)', 'Review your 1098-T form for a specific tax year.'],
];

const REGISTRATION_TILES = [
  ['browse', 'Browse Classes', 'Look up class offerings by term.'],
  ['planahead', 'Plan Ahead', 'Get a head start by building plans. When you\'re ready to register, you\'ll be able to load these plans into registration.'],
  ['prep', 'Prepare for Registration', 'View registration status, update student term data, and complete pre-registration requirements.'],
  ['register', 'Register for Classes', 'Search and register for your classes. You can also view and manage your schedule.'],
  ['info', 'View Registration Information', 'View your past schedules and your ungraded classes.'],
];

function tileHtml(act, id, title, text) {
  return `<button class="tile" data-act="${act}" data-v="${id}" data-hint="tile-${id}">${TILE_ICON}<span><b>${title}</b><span>${text}</span></span></button>`;
}

function homeHtml() {
  return `
    <div class="home-tabs"><span>All Users</span><span class="on">Students</span><span>Financial Aid</span></div>
    <h2 class="home-h">Students</h2>
    <div class="tiles">${STUDENT_TILES.map(([t, d], i) => tileHtml('tile-other', 'o' + i, t, d)).join('')}</div>
    <h2 class="home-h">Registration</h2>
    <div class="tiles">${REGISTRATION_TILES.map(([id, t, d]) => tileHtml('tile', id, t, d)).join('')}</div>`;
}

/* ---- Registration landing ("What would you like to do?") -------------------------------- */

const LANDING_LINKS = [
  ['prep', 'Prepare for Registration', 'View registration status, update student term data, and complete pre-registration requirements.'],
  ['register', 'Register for Classes', 'Search and register for your classes. You can also view and manage your schedule.'],
  ['planahead', 'Plan Ahead', 'Give yourself a head start by building plans. When you\'re ready to register, you\'ll be able to load these plans.'],
  ['browse', 'Browse Classes', 'Looking for classes? In this section you can browse classes you find interesting.'],
  ['info', 'View Registration Information', 'View your past schedules and your ungraded classes.'],
];

/** Simple hand-drawn icons (not the real page's artwork). */
const LANDING_ICONS = {
  prep: '<svg viewBox="0 0 28 28"><rect x="5" y="4" width="18" height="21" rx="2" fill="#8a6d3b"/><rect x="8" y="7" width="12" height="15" fill="#fff"/><rect x="10" y="10" width="8" height="1.6" fill="#999"/><rect x="10" y="14" width="8" height="1.6" fill="#999"/></svg>',
  register: '<svg viewBox="0 0 28 28"><rect x="4" y="6" width="20" height="17" rx="1" fill="#fff" stroke="#888"/><rect x="4" y="6" width="20" height="5" fill="#c8102e"/><path d="M9 17l3 3 7-7" stroke="#2e7d32" stroke-width="2.2" fill="none"/></svg>',
  planahead: '<svg viewBox="0 0 28 28"><rect x="4" y="5" width="20" height="18" rx="1" fill="#2a8fd4"/><rect x="7" y="9" width="14" height="2" fill="#fff"/><rect x="7" y="13" width="10" height="2" fill="#fff"/><rect x="7" y="17" width="12" height="2" fill="#7fe07f"/></svg>',
  browse: '<svg viewBox="0 0 28 28"><circle cx="12" cy="12" r="7" fill="none" stroke="#555" stroke-width="2.5"/><path d="M17 17l6 6" stroke="#555" stroke-width="3"/></svg>',
  info: '<svg viewBox="0 0 28 28"><path d="M3 9h8l2 2h12v12H3z" fill="#f2b705"/><path d="M3 7h8l2 2" fill="none" stroke="#c99400"/></svg>',
};

function landingHtml() {
  const items = LANDING_LINKS.map(([id, title, text]) => `
    <div class="it">
      <span class="land-ico">${LANDING_ICONS[id]}</span>
      <div><button class="lnk" data-act="link" data-v="${id}" data-hint="link-${id}">${title}</button><span>${text}</span></div>
    </div>`).join('');
  return `<div class="land-box"><div class="land-in"><div class="land-h">What would you like to do?</div><div class="bw-links">${items}</div></div></div>`;
}

/* ---- Select a Term ------------------------------------------------------------------------- */

function termSelectHtml(id, value, change, hint) {
  const terms = [['', 'Select a term...'], ['202630', 'Fall 2026 (View Only)'], [TERM.code, TERM.name], ['202750', 'Summer 2027']];
  return `<span class="selwrap term"><select id="${id}" data-chg="${change}" data-hint="${hint}">${optionsHtml(terms, value)}</select><i></i></span>`;
}

/** The framed "Terms Open for Registration" box, shared by two pages. */
function termBoxHtml(selectId, value, change, selectHint, continueAct) {
  return `
    <div class="term-box"><div class="term-in">
      <label for="${selectId}" class="term-lbl">Terms Open for Registration</label>
      ${termSelectHtml(selectId, value, change, selectHint)}
      <div class="term-go"><button class="bw-btn cont" data-act="${continueAct}" data-hint="${continueAct}">Continue</button></div>
    </div></div>`;
}

function termHtml() {
  return termBoxHtml('termsel', state.termSel, 'term', 'term-select', 'term-continue');
}

/* ---- Prepare for Registration ----------------------------------------------------------------- */

function prepHtml() {
  const P = state.prep;
  if (P.stage === 'select' && !state.agreementAccepted) {
    return termBoxHtml('prepterm', P.term, 'prep-term', 'prep-term', 'prep-continue');
  }
  const ok = (t) => `<li class="okrow"><span class="ic ok">✓</span><span>${t}</span></li>`;
  const bad = (t) => `<li class="norow"><span class="ic no">!</span><span>${t}</span></li>`;

  return `
    <div class="bw-tabs">
      <button class="bw-tab" aria-selected="true">Registration Status</button>
      <span class="tabs-end"><button class="bw-btn gray" data-act="prep-done" data-hint="prep-done">Continue</button></span>
    </div>
    <div class="bw-frame"><div class="bw-frame-in prep-grid">
      <div>
        <div class="prep-h">Registration Status</div>
        <div class="prep-t">Term: ${TERM.name}</div>
        <ul class="statuslist">
          ${ok('Your Student Status permits registration.')}
          ${ok('You have no holds which prevent registration.')}
          ${ok('Your academic status permits registration.')}
          ${ok(`Your Advised Status is ADVISED for ${TERM.name}.`)}
          ${state.agreementAccepted
            ? ok(`Financial Responsibility Agreement accepted for ${TERM.name}.`)
            : bad(`Financial Responsibility Agreement has not been accepted for ${TERM.name}.`)}
        </ul>
        ${state.agreementAccepted ? '' : `
          <div class="fra-box">
            <label class="fra-check"><input type="checkbox" id="fra" data-chg="fra" data-hint="fra-check" ${P.fraChecked ? 'checked' : ''}> Financial Responsibility Agreement</label>
            <div class="fra-save"><button class="bw-btn gray" data-act="fra-save" data-hint="fra-save">SAVE</button></div>
          </div>`}
      </div>
      <div class="curr">
        <div class="curr-h">Primary Curriculum</div>
        <dl>
          <dt>Level:</dt><dd>Undergraduate Units</dd>
          <dt>College:</dt><dd>School of Arts and Sciences</dd>
          <dt>Degree:</dt><dd>Undeclared</dd>
          <dt>Catalog Term:</dt><dd>Fall 2026</dd>
          <dt>Admit Term:</dt><dd>Fall 2026</dd>
          <dt>Major:</dt><dd>Undeclared</dd>
        </dl>
      </div>
    </div></div>`;
}

/* ---- View Registration Information ----------------------------------------------------------------- */

function infoHtml() {
  const rows = state.summary.filter((r) => r.status === 'registered' || r.status === 'waitlisted');
  const body = rows.length ? rows.map((r) => {
    const s = state.byCrn[r.crn];
    return `<tr>
      <td class="ttl"><button class="tlink" data-act="details" data-crn="${s.crn}">${escapeHtml(s.title)}</button></td>
      <td>${escapeHtml(courseKey(s))}, ${escapeHtml(s.sec)}</td><td>${r.status === 'registered' ? s.units : 0}</td><td>${s.crn}</td>
      <td>Lecture</td><td>Standard Grading</td><td>Undergraduate</td><td>Full Term</td><td>${statusText(r)}</td>
      <td>${r.status === 'registered' ? '**Web Registered**' : 'Wait Listed'}</td></tr>`;
  }).join('') : '<tr><td colspan="10">No registered classes for this term.</td></tr>';

  return `
    <div class="bw-tabs"><button class="bw-tab" aria-selected="true">Look up a Schedule</button><button class="bw-tab" aria-selected="false">Active Registrations</button></div>
    <div class="bw-frame"><div class="bw-frame-in">
      <div class="sc-h">Class Schedule</div><div class="sc-t"><b>Term:</b> ${TERM.name}</div>
      <div class="sum-scroll info-table"><table class="sm" style="min-width:900px">
        <thead><tr><th>Title</th><th>Details</th><th>Hours</th><th>CRN</th><th>Schedule Type</th><th>Grade Mode</th><th>Level</th><th>Part of Term</th><th>Status</th><th>Message</th></tr></thead>
        <tbody>${body}</tbody></table></div>
      <div class="sum-tot">Records: ${rows.length}</div>
    </div></div>
    <div class="lp info-cal"><div class="lp-tabs"><button class="lp-tab" aria-selected="true">Schedule</button></div>
      <div class="lp-sub">Class Schedule for ${TERM.name}</div><div class="cal-scroll" id="cal-scroll">${calendarHtml()}</div></div>`;
}

/* ---- Select A Plan (reconstructed; the guide doesn't show this page) ------------------------------- */

function selectPlanHtml() {
  const plans = state.scen === 'planahead'
    ? '<tr><td colspan="3">You have no plans for this term.</td></tr>'
    : `<tr><td>${escapeHtml(PLAN_NAME)}</td><td>You</td><td>Yes</td></tr>`;
  return `
    <div class="bw-frame"><div class="bw-frame-in selplan">
      <div class="sc-h">Plans for ${TERM.name}</div><div class="sc-t">You can have up to three (3) plans for each term.</div>
      <table class="sm selplan-table"><thead><tr><th>Plan Name</th><th>Created By</th><th>Preferred</th></tr></thead><tbody>${plans}</tbody></table>
      <div class="selplan-new"><button class="bw-btn cont wide" data-act="create-plan" data-hint="create-plan">Create a New Plan</button></div>
    </div></div>`;
}

/* ---- Pages that exist but can't register you ---------------------------------------------------------- */

function notRegisteringHtml() {
  const why = {
    planahead: 'Plan Ahead is where you build and save plans. Yours is already saved, and nothing on this page registers you.',
    info: 'This shows schedules you are already registered for. Use it to double-check after you submit, not to register.',
  }[state.screen] || 'This page only looks classes up. You cannot register from here.';
  return `<p class="plain-note">${why}</p><button class="bw-btn sec" data-act="go-landing">Back to Registration</button>`;
}
