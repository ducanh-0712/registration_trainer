/* =============================================================================
   views/register.js — Register for Classes.

   Layout, top to bottom (matches the real page):
     tabs: Find Classes | Enter CRNs | Plans | Schedule and Options
     framed panel for the open tab
     splitter (▲ ● ▼)
     lower panels: Schedule / Schedule Details on the left, Summary on the right
     footer: Panels ▾ … Conditional Add and Drop, Submit
   Several pieces (search form, calendar, splitter) are reused by Plan Ahead.
   ========================================================================== */
"use strict";

const CALENDAR_ICON = '<svg viewBox="0 0 16 16"><path d="M3 1h2v2h6V1h2v2h2v12H1V3h2zm-1 5v8h12V6z"/></svg>';
const LIST_ICON = '<svg viewBox="0 0 16 16"><path d="M1 2h2v2H1zm4 0h10v2H5zM1 7h2v2H1zm4 0h10v2H5zm-4 5h2v2H1zm4 0h10v2H5z"/></svg>';

/* ---- Page ---------------------------------------------------------------------------- */

function registerHtml() {
  const upper = { find: findClassesHtml, crn: enterCrnsHtml, plans: plansHtml, sched: scheduleOptionsHtml }[state.tab]();
  const P = state.panels;
  const showUpper = P.upper && state.split !== 'up';
  const showLower = state.split !== 'down' && (P.sched || P.summary);

  const sched = P.sched ? schedulePanelHtml(false) : '';
  const summary = P.summary ? summaryPanelHtml() : '';

  return (showUpper ? registerTabsHtml() + framedHtml(upper) : '') +
    splitterHtml() +
    (showLower ? `<div class="bw-lower ${sched && summary ? '' : 'one'}">${sched}${summary}</div>` : '');
}

function registerTabsHtml() {
  const tabs = [['find', 'Find Classes'], ['crn', 'Enter CRNs'], ['plans', 'Plans'], ['sched', 'Schedule and Options']];
  return '<div class="bw-tabs" role="tablist">' + tabs.map(([id, label]) =>
    `<button class="bw-tab" role="tab" aria-selected="${state.tab === id}" data-act="tab" data-v="${id}" data-hint="tab-${id}">${label}</button>`
  ).join('') + '</div>';
}

/** The grey-blue frame with a rounded white inside. */
const framedHtml = (inner) => `<div class="bw-frame"><div class="bw-frame-in">${inner}</div></div>`;

function splitterHtml() {
  return `<div class="bw-split"><div>
    <button data-act="split" data-v="up" aria-label="Expand lower panels">▲</button>
    <button data-act="split" data-v="mid" aria-label="Show both">●</button>
    <button data-act="split" data-v="down" aria-label="Expand upper panel">▼</button>
  </div></div>`;
}

/* ---- Find Classes: search form ---------------------------------------------------------- */

/** The Subject drop-down list, filtered by what has been typed (matches that start with it first). */
function subjectListHtml() {
  const q = (state.find.subj || '').trim().toLowerCase();
  const name = (c) => subjectName(c).toLowerCase();
  const startsWith = (c) => name(c).startsWith(q) || c.toLowerCase().startsWith(q);
  const codes = [...new Set(Object.keys(SUBJECT_NAMES).concat(state.sections.map((s) => s.subj)))];
  const list = codes
    .filter((c) => !q || name(c).includes(q) || c.toLowerCase().startsWith(q))
    .sort((a, b) => (startsWith(a) ? 0 : 1) - (startsWith(b) ? 0 : 1) || name(a).localeCompare(name(b)));

  const options = list.length
    ? list.map((c, i) => `<button class="s2-opt${i === 0 ? ' on' : ''}" data-act="subj-pick" data-v="${c}" role="option">${escapeHtml(subjectName(c))}</button>`).join('')
    : '<div class="s2-none">No matches found</div>';
  return `<div class="s2-list" role="listbox">${options}</div>`;
}

function searchFormHtml() {
  const F = state.find;
  const code = resolveSubject(F.subj);
  const chip = code
    ? `<span class="s2-chip"><button class="s2-x" data-act="subj-clear" aria-label="Remove subject">×</button>${escapeHtml(subjectName(code))}</span>`
    : '';
  return `
    <div class="sc-box${F.err ? ' err' : ''}">
      <div class="sc-h">Enter Your Search Criteria</div>
      <div class="sc-t"><b>Term: ${TERM.name}</b></div>
      <div class="sc-grid">
        <label for="f-subj">Subject</label>
        <div class="s2" data-hint="find-subj">${chip}<input id="f-subj" data-inp="subj" value="${code ? '' : escapeHtml(F.subj)}" autocomplete="off" aria-label="Subject">${F.open ? subjectListHtml() : ''}</div>
        <label for="f-num">Course Number</label>
        <input class="bw-in sc-num" id="f-num" data-inp="num" data-hint="find-num" value="${escapeHtml(F.num)}" title="These special characters are ignored. The % is allowed.">
        <label for="f-kw">Keyword</label>
        <input class="bw-in sc-kw" id="f-kw" data-inp="kw" value="${escapeHtml(F.kw)}">
        <span></span>
        <div class="sc-btns">
          <button class="bw-btn cont" data-act="find-search" data-hint="find-search">Search</button>
          <button class="lnk" data-act="find-clear">Clear</button>
          <button class="lnk adv" data-act="adv"><span class="tri"></span>Advanced Search</button>
        </div>
      </div>
    </div>`;
}

/* ---- Find Classes: search results -------------------------------------------------------- */

const RESULT_COLUMNS = [
  ['Title', 130], ['Subject Description', 86], ['Course Number', 52], ['Section', 52], ['Hours', 46],
  ['CRN', 62], ['Term', 86], ['Instructor', 100], ['Meeting Times', 190], ['Campus', 58],
  ['Status', 92], ['Schedule Type', 76], ['Attribute', 90], ['Linked Sections', 80], ['Add', 70],
];

function seatStatusHtml(s) {
  const left = seatsLeft(s);
  if (left > 0) return `<div class="stat-line plain">${left} of ${s.cap} seats remain.</div>`;
  const full = `<div class="stat-line ful"><span class="ic-full">!</span>FULL: 0 of ${s.cap} seats remain.</div>`;
  const wait = s.waitCap ? `<div class="stat-line"><span class="ic-wl"></span>${s.waitCap - s.waitCount} of ${s.waitCap} waitlist seats remain.</div>` : '';
  return full + wait;
}

function resultRowHtml(s) {
  const inPlanAhead = state.screen === 'planahead';
  const added = inPlanAhead
    ? state.planAhead.draft.some((d) => d.crn === s.crn)
    : !!summaryRow(s.crn) && summaryRow(s.crn).status !== 'dropped';
  const times = `${formatClassTime(s.start)} - ${formatClassTime(s.end)}`;
  const left = seatsLeft(s);
  const tip = left > 0 ? `${left} of ${s.cap} seats remain.`
    : `FULL: 0 of ${s.cap} seats remain.` + (s.waitCap ? ` ${s.waitCap - s.waitCount} of ${s.waitCap} waitlist seats remain.` : '');

  return `<tr>
    <td class="ttl" title="${escapeHtml(s.title)}"><button class="tlink" data-act="details" data-crn="${s.crn}">${escapeHtml(s.title)}</button></td>
    <td title="${escapeHtml(subjectName(s.subj))}">${escapeHtml(subjectName(s.subj))}</td>
    <td>${escapeHtml(s.num)}</td><td>${escapeHtml(s.sec)}</td><td>${s.units}</td><td>${s.crn}</td>
    <td title="${TERM.name}">${TERM.name}</td>
    <td class="ins" title="${escapeHtml(s.instr)}">${escapeHtml(s.instr)}</td>
    <td title="${escapeHtml(s.days)} ${times}">${daysHtml(s.days)}${times}</td>
    <td title="Main">Main</td>
    <td title="${escapeHtml(tip)}">${seatStatusHtml(s)}</td>
    <td>Lecture</td><td></td><td></td>
    <td><button class="bw-btn gray" data-act="add-sec" data-crn="${s.crn}" data-hint="add-${s.crn}" ${added ? 'disabled' : ''}>Add</button></td>
  </tr>`;
}

function searchResultsHtml() {
  const F = state.find;
  const inPlanAhead = state.screen === 'planahead';
  const per = state.per || 10;
  const pages = Math.max(1, Math.ceil(F.results.length / per));
  const subj = F.subj.trim().toUpperCase();
  const what = F.subj
    ? `&nbsp;&nbsp;&nbsp;<b>Subject${F.num ? ' and Course Number' : ''}:</b> ${escapeHtml(subj + (F.num || ''))} ${escapeHtml(SUBJECT_NAMES[subj] || '')}`
    : '';
  const rows = F.results.slice(0, per).map((crn) => resultRowHtml(state.byCrn[crn])).join('')
    || '<tr><td colspan="15">No classes found. Check the subject and course number.</td></tr>';

  // Plan Ahead puts "Catalog Search Results" on the left; Register puts "Search Again" on the right.
  return `
    <div class="sr-head">
      ${inPlanAhead ? '<button class="bw-btn cont cat-back" data-act="find-again" data-hint="find-again">Catalog Search Results</button>' : ''}
      <div><div class="t">Search Results — ${F.results.length} Classes</div><div class="m"><b>Term:</b> ${TERM.name}${what}</div></div>
      ${inPlanAhead ? '' : '<span class="r"><button class="bw-btn green" data-act="find-again" data-hint="find-again">Search Again</button></span>'}
    </div>
    <div class="sr-scroll"><table class="sr">
      <colgroup>${RESULT_COLUMNS.map(([, w]) => `<col style="width:${w}px">`).join('')}</colgroup>
      <thead><tr>${RESULT_COLUMNS.map(([h]) => `<th title="${h}">${h}</th>`).join('')}</tr></thead>
      <tbody>${rows}</tbody>
    </table></div>
    <div class="pager">
      <span class="pg-nav" aria-hidden="true">|◂ &nbsp;◂</span><span>Page <b>1</b> of ${pages}</span><span class="pg-nav" aria-hidden="true">▸ &nbsp;▸|</span>
      <span class="pg-sep">|</span>
      <span class="selwrap act"><select data-chg="per" aria-label="Per page">${optionsHtml([10, 20, 50].map((n) => [n, n]), per)}</select><i></i></span> Per Page
      <span class="pg-rec">Records: ${F.results.length}</span>
    </div>`;
}

function findClassesHtml() {
  return state.find.results ? searchResultsHtml() : searchFormHtml();
}

/* ---- Enter CRNs ------------------------------------------------------------------------------ */

/** Live lookup shown next to a CRN box as you type. */
function crnLookupHtml(crn) {
  if (!crn) return '';
  const s = state.byCrn[crn];
  if (s) return `${escapeHtml(s.title)} · ${escapeHtml(courseKey(s))}, ${escapeHtml(s.sec)}`;
  return crn.length === 5 ? `<span class="crn-bad">CRN not found for ${TERM.name}</span>` : '';
}

function enterCrnsHtml() {
  const rows = state.crnInputs.map((v, i) => `
    <div class="crn-row">
      <label for="crn-${i}">CRN</label>
      <input class="bw-in" id="crn-${i}" data-crn-i="${i}" data-hint="crn-input-${i}" value="${escapeHtml(v)}" inputmode="numeric" maxlength="5">
      <span id="crn-t-${i}" class="crn-t">${crnLookupHtml(v)}</span>
    </div>`).join('');
  return `
    <div class="sc-h">Enter Course Reference Numbers (CRNs) to Register</div><div class="sc-t"><b>Term:</b> ${TERM.name}</div>
    <div class="crn-wrap">${rows}
      <div class="crn-btns">
        <button class="lnk" data-act="crn-more">+ Add Another CRN</button>
        <button class="bw-btn dark" data-act="crn-add" data-hint="crn-add">Add to Summary</button>
      </div>
    </div>`;
}

/* ---- Plans ("Register from a plan.", as in the Registrar's guide) -------------------------------- */

function plansHtml() {
  const rows = state.plan.map((p) => {
    const r = p.crn ? summaryRow(p.crn) : null;
    const added = r && r.status !== 'dropped';
    const title = p.crn
      ? `<button class="tlink" data-act="details" data-crn="${p.crn}">${escapeHtml(p.title)}</button>`
      : escapeHtml(p.title.toUpperCase());
    return `<tr>
      <td class="ttl" title="${escapeHtml(p.title)}">${title}</td>
      <td>${escapeHtml(courseKey(p))}${p.crn ? ', ' + escapeHtml(p.sec) : ''}</td>
      <td>${p.units}</td><td>${p.crn || ''}</td><td>${p.crn ? 'Lecture' : ''}</td><td></td>
      <td title="Standard Grading Mode">Standard Grading Mode</td><td></td>
      <td><button class="pbtn" data-act="plan-view" data-i="${p.idx}" data-hint="view-${p.idx}"><span class="mag"></span>View Sections</button></td>
      <td>${p.crn ? `<button class="pbtn" data-act="plan-add" data-crn="${p.crn}" ${added ? 'disabled' : ''}><span class="plusbox">+</span>Add</button>` : ''}</td>
      <td></td>
    </tr>`;
  }).join('');

  const open = state.planOpen;
  const widths = [13, 9, 5, 5, 8, 11, 9, 4, 16, 17, 3];
  const table = open ? `
    <table class="rfp-t2">
      <colgroup>${widths.map((w) => `<col style="width:${w}%">`).join('')}</colgroup>
      <thead><tr><th>Title</th><th>Details</th><th>Hours</th><th>CRN</th><th>Schedule Type</th><th>Instructor</th><th>Grade Mode</th><th>Note</th><th>Course Sections</th><th>Add</th><th class="gearth"><span class="gear2">⚙</span></th></tr></thead>
      <tbody>${rows}</tbody>
    </table>` : '';

  return `
    <div class="rfp-wrap">
      <div class="rfp-h">Register from a plan.</div><div class="rfp-t">Term: ${TERM.name}</div>
      <div class="rfp-bar">
        <div class="rfp-l">
          <button class="rfp-tog" data-act="plan-tog" aria-expanded="${open}" aria-label="Show or hide plan">${open ? '▾' : '▸'}</button>
          <span class="rfp-cal"></span><span>Plan: ${escapeHtml(PLAN_NAME)}</span>
        </div>
        <div class="rfp-r">
          <span class="rfp-by"><b>Created by:</b> You (Preferred)</span>
          <span class="rfp-cell"><button class="pbtn big" data-act="plan-addall" data-hint="add-all"><span class="plusbox">+</span>Add All</button></span>
        </div>
      </div>
      ${table}
    </div>`;
}

/* ---- Schedule and Options ----------------------------------------------------------------------- */

function scheduleOptionsHtml() {
  const registered = state.summary.filter((r) => r.status === 'registered');
  const list = registered.length
    ? '<ul class="opts-list">' + registered.map((r) => {
        const s = state.byCrn[r.crn];
        return `<li>${escapeHtml(s.title)} · ${escapeHtml(courseKey(s))}, ${escapeHtml(s.sec)} · CRN ${s.crn}</li>`;
      }).join('') + '</ul>'
    : 'You are not registered for any classes this term yet.';
  return `<div class="opts"><div class="opts-h">Schedule and Options</div><div class="opts-b">${list}<p class="opts-note">No grading-mode or credit-hour options are available for these classes.</p></div></div>`;
}

/* ---- Lower left: Schedule calendar / Schedule Details ---------------------------------------------- */

/** Calendar, Sunday to Saturday, 6am–10pm. 50px per hour, like the real page. */
function calendarHtml() {
  const PX_PER_MIN = 50 / 60;
  const FIRST_HOUR = 6;
  const hours = [];
  for (let h = FIRST_HOUR; h <= 22; h++) hours.push(h);
  const dayCodes = ['U', 'M', 'T', 'W', 'R', 'F', 'A'];
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  // In Plan Ahead the calendar shows the draft plan; elsewhere the Summary.
  const items = state.screen === 'planahead'
    ? state.planAhead.draft.map((d) => ({ r: { status: d.status === 'planned' ? 'registered' : 'pending', crn: d.crn, planned: d.status === 'planned' }, s: state.byCrn[d.crn] }))
    : state.summary.filter((r) => r.status !== 'dropped').map((r) => ({ r, s: state.byCrn[r.crn] }));
  const counting = items.filter((x) => x.r.status !== 'error');

  const blocksFor = (day) => items.filter((x) => x.s.days.includes(day)).map((x) => {
    const top = (toMinutes(x.s.start) - FIRST_HOUR * 60) * PX_PER_MIN;
    const height = Math.max(16, (toMinutes(x.s.end) - toMinutes(x.s.start)) * PX_PER_MIN);
    const clash = x.r.status !== 'error' && counting.some((y) => y !== x && overlaps(y.s, x.s));
    const kind = { pending: 'p', error: 'e', waitlisted: 'w' }[x.r.status] || '';
    const label = x.r.planned ? 'Planned' : statusText(x.r);
    return `<div class="blk ${kind} ${clash ? 'x' : ''}" style="top:${top}px;height:${height}px" title="${escapeHtml(x.s.title)} ${escapeHtml(courseKey(x.s))}, ${escapeHtml(x.s.sec)} (${statusText(x.r)})">`
      + (x.r.status === 'registered' ? '<span class="ck">✓</span>' : '')
      + `<u>${escapeHtml(x.s.subj + x.s.num)}</u><br><u>(${label})</u></div>`;
  }).join('');

  const columnHeight = (hours.length - 1) * 60 * PX_PER_MIN;
  const hourLabels = hours.slice(0, -1).map((h, i) =>
    `<span style="top:${i * 60 * PX_PER_MIN + 4}px">${(h % 12) || 12}${h < 12 ? 'am' : 'pm'}</span>`).join('');

  return `<div class="cal7">
    <div class="hd"></div>${dayNames.map((n) => `<div class="hd">${n}</div>`).join('')}
    <div class="tcol" style="height:${columnHeight}px">${hourLabels}</div>
    ${dayCodes.map((d) => `<div class="day" style="height:${columnHeight}px">${blocksFor(d)}</div>`).join('')}
  </div>`;
}

function scheduleDetailsHtml() {
  if (!state.summary.length) return '<span class="muted">Nothing scheduled yet.</span>';
  return '<table class="bw-t"><tbody>' + state.summary.map((r) => {
    const s = state.byCrn[r.crn];
    return `<tr><td><b>${escapeHtml(s.title)}</b><br>${escapeHtml(courseKey(s))}, ${escapeHtml(s.sec)} · CRN ${s.crn}<br>${escapeHtml(s.instr)}</td>`
      + `<td class="nowrap">${daysHtml(s.days)}<span class="nowrap">${formatClassTime(s.start)} - ${formatClassTime(s.end)}</span></td></tr>`;
  }).join('') + '</tbody></table>';
}

/**
 * Lower-left panel. `withTip` adds the blue keyboard-shortcut bubble
 * (the guide shows it on Plan Ahead).
 */
function schedulePanelHtml(withTip) {
  const body = state.lowTab === 'sched'
    ? `<div class="cal-scroll" id="cal-scroll">${calendarHtml()}</div>`
    : `<div class="sum-scroll">${scheduleDetailsHtml()}</div>`;
  const tip = withTip && !state.tipHidden
    ? '<div class="kb-tip">Display or hide additional registration information using Ctrl + Alt + V. Use Ctrl + Alt + C to reset all panels.<button data-act="tip-x" aria-label="Dismiss">×</button></div>'
    : '';
  const lowTab = (id, icon, label) =>
    `<button class="lp-tab" aria-selected="${state.lowTab === id}" data-act="lowtab" data-v="${id}">${icon}${label}</button>`;
  return `
    <div class="lp">
      <div class="lp-tabs">${lowTab('sched', CALENDAR_ICON, 'Schedule')}${lowTab('details', LIST_ICON, 'Schedule Details')}</div>
      <div class="lp-sub">Class Schedule for ${TERM.name}</div>
      ${withTip ? `<div class="lp-body">${body}${tip}</div>` : body}
    </div>`;
}

/* ---- Lower right: Summary ------------------------------------------------------------------------ */

/** Action choices for a Summary row, by status (labels match the real drop-down). */
function rowActions(r, s) {
  switch (r.status) {
    case 'pending':    return [['register', '**Web Registered**'], ['remove', 'Remove']].concat(canWaitlist(s) ? [['waitlist', 'Wait List']] : []);
    case 'registered':
    case 'waitlisted': return [['none', 'None'], ['drop', 'Drop/No Refund']];
    case 'dropped':    return [['none', 'None']];
    default:           return [['remove', 'Remove']].concat(r.wl ? [['waitlist', 'Wait List']] : []);
  }
}

function summaryTableHtml() {
  if (!state.summary.length) {
    return '<div class="sum-empty">No classes in your Summary. Add sections from Plans, Find Classes or Enter CRNs.</div>';
  }
  const pillClass = { pending: 'pend', registered: 'reg', waitlisted: 'wl', dropped: 'reg', error: 'err' };
  const rows = state.summary.map((r) => {
    const s = state.byCrn[r.crn];
    const hours = r.status === 'registered' || r.status === 'pending' ? s.units : 0;
    const select = `<span class="selwrap act"><select data-chg="row-act" data-crn="${r.crn}" data-hint="act-${r.crn}" aria-label="Action for CRN ${r.crn}">${optionsHtml(rowActions(r, s), r.action)}</select><i></i></span>`;
    return `<tr class="${r.status === 'error' ? 'row-err' : ''}">
      <td class="ttl" title="${escapeHtml(s.title)}"><button class="tlink" data-act="details" data-crn="${s.crn}">${escapeHtml(s.title)}</button></td>
      <td title="${escapeHtml(courseKey(s))}, ${escapeHtml(s.sec)}">${escapeHtml(courseKey(s))}, ${escapeHtml(s.sec)}</td>
      <td>${hours}</td><td>${s.crn}</td><td>Lecture</td>
      <td title="${escapeHtml(statusText(r) + (r.msg ? ' - ' + r.msg : ''))}"><span class="pill-st ${pillClass[r.status]}">${statusText(r)}</span>${r.msg ? `<div class="err-msg">${escapeHtml(r.msg)}</div>` : ''}</td>
      <td>${select}</td>
    </tr>`;
  }).join('');
  const widths = [21, 13, 6, 9, 10, 16, 25];
  return `<table class="sm" style="min-width:560px">
    <colgroup>${widths.map((w) => `<col style="width:${w}%">`).join('')}</colgroup>
    <thead><tr><th>Title</th><th>Details</th><th title="Hours">Hours</th><th>CRN</th><th title="Schedule Type">Schedule Type</th><th>Status</th><th>Action</th></tr></thead>
    <tbody>${rows}</tbody></table>`;
}

function summaryPanelHtml() {
  const registered = state.summary.filter((r) => r.status === 'registered').reduce((sum, r) => sum + unitsOf(state.byCrn[r.crn]), 0);
  return `
    <div class="lp">
      <div class="sum-h">${LIST_ICON}Summary</div>
      <div class="sum-scroll">${summaryTableHtml()}</div>
      <div class="sum-tot">Total Hours | Registered: <b>${registered}</b> | Billing: <b>${registered}</b> | CEU: <b>0</b> | Min: <b>0</b> | Max: <b>${MAX_HOURS}</b></div>
    </div>`;
}

/* ---- Footer: Panels menu, Conditional Add and Drop, Submit -------------------------------------------- */

function panelsMenuHtml(labels) {
  if (!state.panelsMenu) return '';
  const P = state.panels;
  const item = (id, label) => `<label><input type="checkbox" data-chg="panel" data-v="${id}" ${P[id] ? 'checked' : ''}> ${label}</label>`;
  return `<div class="panels-menu" role="menu">${item('upper', labels[0])}${item('sched', labels[1])}${item('summary', labels[2])}</div>`;
}

function registerFooterHtml() {
  return `
    <div class="bw-foot">
      ${panelsMenuHtml(['Search / Plans / CRNs', 'Schedule', 'Summary'])}
      <button class="panels-btn" data-act="panels" aria-expanded="${state.panelsMenu}">Panels ▾</button>
      <div class="rt">
        <label data-hint="cond"><input type="checkbox" id="cond" data-chg="cond" ${state.cond ? 'checked' : ''}> Conditional Add and Drop</label>
        <i class="info-i" title="When checked, drops are only processed if every add in the same submission succeeds.">i</i>
        <button class="bw-btn dark" data-act="submit" data-hint="submit" ${hasChanges() ? '' : 'disabled'}>Submit</button>
      </div>
    </div>`;
}
