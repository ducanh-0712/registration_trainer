/* =============================================================================
   views/trainer.js — the parts that belong to the trainer, not to BannerWeb:
   the start screen, the hidden trainer bar (Esc), the hint box, and the
   results window at the end of a run.
   ========================================================================== */
"use strict";

/* ---- Start screen ------------------------------------------------------------------------ */

function gradeHtml(grade) {
  const label = { ready: 'Ready', close: 'Close' }[grade] || 'Keep practicing';
  const cls = { ready: 'g', close: 'y' }[grade] || 'r';
  return `<span class="pill ${cls}">${label}</span>`;
}

function renderStart() {
  clearInterval(clockTimer);
  const when = (iso) => new Date(iso).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  const runs = runHistory.length ? `
    <div class="table-scroll"><table class="hist">
      <thead><tr><th>When</th><th>Scenario</th><th>Time</th><th>Mistakes</th><th>Result</th></tr></thead>
      <tbody>${runHistory.slice(0, 15).map((h) => `
        <tr><td>${escapeHtml(when(h.d))}</td><td>${escapeHtml(SCENARIOS[h.scen] ? SCENARIOS[h.scen].name : h.scen)}</td>
        <td class="num">${formatDuration(h.t)}</td><td class="num">${h.mis}</td><td>${gradeHtml(h.grade)}</td></tr>`).join('')}
      </tbody></table></div>`
    : '<p class="start-note">No runs yet.</p>';

  qs('#app').innerHTML = `
    <main class="wrap start">
      <button class="btn-primary start-go" data-act="start">Start</button>
      <p class="start-note">Clean load, timed. Press Esc during a run for the timer, Restart and Exit.</p>
      <h2 class="start-h">Your runs</h2>
      ${runs}
    </main>`;
}

/* ---- Trainer bar (hidden until Esc) ------------------------------------------------------------ */

function trainerBarHtml() {
  const scenario = SCENARIOS[state.scen];
  let brief = state.surprise ? 'Your time ticket opens at 7:00:00 AM. Register your whole plan. Something may go wrong.' : scenario.brief;
  if (state.scen === 'swap') {
    const o = state.byCrn[state.targets.swapOld];
    const n = state.byCrn[state.targets.swapNew];
    brief = `You are registered. Switch <b>${escapeHtml(courseKey(o))}</b> from section ${escapeHtml(o.sec)} (CRN ${o.crn}) to section ${escapeHtml(n.sec)} (<b>CRN ${n.crn}</b>, ${escapeHtml(n.days)} ${formatClassTime(n.start)}), without risking your seat.`;
  } else {
    brief = escapeHtml(brief);
  }

  const toast = state.bar || state.escTipShown ? '' : '<div class="esc-toast" id="esc-toast">Press Esc for the timer, Restart and Exit</div>';
  return `
    <div class="tbar" id="tbar" ${state.bar ? '' : 'hidden'}>
      <div class="hud"><div class="wrap">
        <div><div class="lbl">${escapeHtml(state.dateLabel)} · practice clock</div>
          <div class="val"><span id="hud-clock">${formatClock(simNow())}</span><span id="hud-flag" class="open-flag"></span></div></div>
        <div><div class="lbl">Since window opened</div><div class="val" id="hud-el">0:00.0</div></div>
        <div><div class="lbl">Target</div><div class="val">${formatDuration(scenario.target)}</div></div>
        <div><div class="lbl">Mistakes</div><div class="val" id="hud-mis">0</div></div>
        <div class="grow"></div>
        ${state.mode === 'timed' ? '<button data-act="hint">Hint (+5 s)</button>' : ''}
        <button data-act="restart">Restart</button>
        <button data-act="quit">Exit</button>
      </div></div>
      <div class="brief"><div class="wrap"><b>${state.surprise ? 'Surprise run' : escapeHtml(scenario.name)}:</b> ${brief} <span class="esc-tip">Esc hides this bar.</span></div></div>
    </div>
    ${toast}`;
}

/** Show or hide the trainer bar without redrawing the page. */
function toggleTrainerBar() {
  state.bar = !state.bar;
  const bar = document.getElementById('tbar');
  if (bar) bar.hidden = !state.bar;
  const toast = document.getElementById('esc-toast');
  if (toast) toast.remove();
}

/* ---- Hint box + outline on the next thing to click --------------------------------------------- */

function renderHint() {
  document.querySelectorAll('.hint-glow').forEach((el) => el.classList.remove('hint-glow'));
  const box = qs('#coach');
  if (!box || !state) return;

  const show = state.mode === 'guided' || Date.now() < hintVisibleUntil;
  if (!show || state.done) {
    if (state.mode !== 'guided') box.hidden = true;
    return;
  }
  const hint = nextHint();
  box.hidden = false;
  if (!hint) { box.innerHTML = ''; return; }

  const html = `<div class="lbl">${state.mode === 'guided' ? 'Next step' : 'Hint'}</div><p>${escapeHtml(hint.text)}</p>`
    + (hint.why ? `<div class="why">${escapeHtml(hint.why)}</div>` : '');
  if (box.dataset.last !== html) { box.innerHTML = html; box.dataset.last = html; }   // avoid flicker on each tick

  if (hint.key) {
    const target = document.querySelector(`[data-hint="${hint.key}"]`);
    if (target) target.classList.add('hint-glow');
  }
}

/* ---- Results ------------------------------------------------------------------------------------------ */

/** Short, specific advice based on what happened in the run. */
function resultTips() {
  const { scen, targets } = state;
  const tips = [];
  if (scen !== 'swap' && state.plan.some((p) => p.crn) && !state.usedAddAll) tips.push('Use Add All in the Plans tab. You clicked Add one course at a time.');
  if (targets.nocrn !== undefined || targets.nocrnUser) tips.push('Before your window, put a CRN on every course in Plan Ahead. Course-only entries cost you a search under pressure.');
  if (targets.closed !== undefined || state.rushFired) tips.push('Write down one backup CRN per course (open, no overlap) and keep it next to you. Enter CRNs is faster than searching.');
  if (scen === 'hold' || scen === 'gauntlet') tips.push('Do Prepare for Registration the day before. It confirms holds, your time ticket and the agreement.');
  if (state.earlyTries > 2) tips.push(`You clicked Continue ${state.earlyTries} times before 7:00. One click right at 7:00:00 is enough.`);
  if (scen === 'waitlist') tips.push('Waitlisted is not registered. A seat offer goes to your Richmond email with a deadline, so check it often.');
  if (scen === 'swap' && state.cond) tips.push('Good: Conditional Add and Drop protects your old seat if the new section fails.');
  if (!tips.length) tips.push('Clean run. Keep it up.');
  return tips;
}

function renderResults() {
  const box = qs('#res');
  if (!box || !state.result) return;
  const { t, grade } = state.result;
  const scenario = SCENARIOS[state.scen];
  const headline = { ready: 'Registered, and fast enough.', close: 'Registered. Tighten it up.' }[grade]
    || 'Registered, but it would have cost you seats.';
  const list = (items) => '<ul>' + items.map((x) => `<li>${escapeHtml(x)}</li>`).join('') + '</ul>';
  const stat = (k, v) => `<div class="stat"><div class="k">${k}</div><div class="v">${v}</div></div>`;

  box.innerHTML = `
    <div class="res-bg"><div class="res" role="dialog" aria-label="Run results">
      <div class="res-kicker">${escapeHtml(scenario.name)} · ${state.mode === 'guided' ? 'Guided' : 'Timed'}</div>
      <h2>${headline} ${gradeHtml(grade)}</h2>
      <div class="stats">
        ${stat('Time', formatDuration(t))}${stat('Target', formatDuration(scenario.target))}
        ${stat('Submits', state.submits)}${stat('Mistakes', state.mistakes.length)}
      </div>
      ${state.mistakes.length ? '<h3>Mistakes</h3>' + list(state.mistakes) : ''}
      <h3>For next time</h3>${list(resultTips())}
      <h3>Timeline</h3>
      <div class="timeline">${state.log.map((l) => `<div><span>${escapeHtml(l.t)}</span>${escapeHtml(l.msg)}</div>`).join('')}</div>
      <div class="res-actions">
        <button class="btn-primary" data-act="restart">Run it again</button>
        <button class="btn" data-act="quit">Back</button>
      </div>
    </div></div>`;
}
