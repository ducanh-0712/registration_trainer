/* =============================================================================
   views/shell.js — the page frame: trainer bar, Banner header, breadcrumbs,
   title, body, footer, notifications, dialogs, hint box and the taskbar clock.

   Rendering is simple on purpose: every change rebuilds #app from `state`.
   ========================================================================== */
"use strict";

const PAGE_TITLES = {
  landing: 'Registration', prep: 'Prepare for Registration', term: 'Select a Term',
  register: 'Register for Classes', selplan: 'Select A Plan', planahead: 'Plan Ahead',
  browse: 'Browse Classes', info: 'View Registration Information',
};

/** Draw whichever view is current. */
function render() {
  document.body.classList.toggle('running', currentView === 'run');
  if (currentView === 'start') renderStart();
  else renderRun();
}

/* ---- Pieces of the Banner header ------------------------------------------------- */

const GEAR_ICON = '<svg viewBox="0 0 24 24"><path d="M19.4 13a7.5 7.5 0 0 0 0-2l2.1-1.6-2-3.5-2.5 1a7.6 7.6 0 0 0-1.7-1L15 3.3h-4l-.4 2.6a7.6 7.6 0 0 0-1.7 1l-2.5-1-2 3.5L6.6 11a7.5 7.5 0 0 0 0 2l-2.1 1.6 2 3.5 2.5-1c.5.4 1.1.7 1.7 1l.4 2.6h4l.4-2.6c.6-.3 1.2-.6 1.7-1l2.5 1 2-3.5zM13 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7z" transform="translate(-1 0)"/></svg>';
const USER_ICON = '<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 4a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7zm0 14a8 8 0 0 1-6.2-3c.9-1.9 3.6-3 6.2-3s5.3 1.1 6.2 3a8 8 0 0 1-6.2 3z"/></svg>';

function bannerHeaderHtml() {
  // The university crest is deliberately replaced by a plain "PRACTICE" badge.
  return `
    <div class="bw-top">
      <div class="bw-logo" aria-label="Practice copy">PRAC<br>TICE</div>
      <div class="bw-right">
        <span class="bw-ico" aria-hidden="true">${GEAR_ICON}</span>
        <span class="bw-ico" aria-hidden="true">${USER_ICON}</span>
        <span class="bw-name">${escapeHtml(STUDENT_NAME)}</span>
        <span class="bw-count" id="bw-count" hidden>0</span>
      </div>
    </div>
    <div class="bw-stripe"></div>`;
}

function breadcrumbsHtml() {
  const s = state.screen;
  const sep = '<span class="sep">●</span>';
  const link = (act, label, hint) => `<button class="lnk" data-act="${act}"${hint ? ` data-hint="${hint}"` : ''}>${label}</button>`;
  const current = (label) => `<span class="cur">${label}</span>`;

  const parts = [link('go-landing', 'Student'), sep,
    s === 'landing' ? current('Registration') : link('go-landing', 'Registration', 'crumb-registration')];
  if (s === 'term') parts.push(sep, current('Select a Term'));
  if (['register', 'selplan', 'planahead'].includes(s)) parts.push(sep, link('go-term', 'Select a Term'));
  if (s === 'planahead') parts.push(sep, link('go-selplan', 'Select A Plan'));
  if (s !== 'landing' && s !== 'term') parts.push(sep, current(PAGE_TITLES[s]));
  return `<nav class="bw-crumbs" aria-label="Breadcrumb">${parts.join('')}</nav>`;
}

/* ---- The whole run view ---------------------------------------------------------------- */

function renderRun() {
  const isHome = state.screen === 'home';
  const footer = state.screen === 'register' ? registerFooterHtml()
    : state.screen === 'planahead' ? planAheadFooterHtml() : '';

  qs('#app').innerHTML = `
    ${trainerBarHtml()}
    <div class="stage"><div class="stage-scroll">
      <div class="bw" id="bw">
        ${bannerHeaderHtml()}
        ${isHome ? '' : `${breadcrumbsHtml()}<div class="bw-title"><h1>${PAGE_TITLES[state.screen]}</h1></div>`}
        <div class="bw-body${isHome ? ' home-body' : ''}">${isHome ? homeHtml() : screenHtml()}</div>
        ${footer}
        <div class="bw-notes" id="bw-notes"></div>
        ${prepDialogHtml()}${classDetailsHtml()}${namePlanDialogHtml()}
      </div>
    </div></div>
    <div class="coach" id="coach" aria-live="polite"${state.mode === 'guided' ? '' : ' hidden'}></div>
    ${taskbarHtml()}
    <div id="res"></div>`;

  fitBanner();
  renderNotes();
  updateClockReadouts();
  renderHint();

  // The "Press Esc" toast is drawn on the first render of a run only; remove it after a few seconds.
  if (!state.escTipShown && !state.bar) {
    state.escTipShown = true;
    setTimeout(() => { const t = document.getElementById('esc-toast'); if (t) t.remove(); }, 3500);
  }

  // Keep the calendar's scroll position across re-renders.
  const cal = qs('#cal-scroll');
  if (cal) {
    cal.scrollTop = state.calScroll != null ? state.calScroll : 0;
    cal.addEventListener('scroll', () => { state.calScroll = cal.scrollTop; }, { passive: true });
  }
  if (state.done && state.showResults) renderResults();
}

/** Which page body to draw for the current screen. */
function screenHtml() {
  switch (state.screen) {
    case 'landing':   return landingHtml();
    case 'term':      return termHtml();
    case 'prep':      return prepHtml();
    case 'register':  return registerHtml();
    case 'info':      return infoHtml();
    case 'selplan':   return selectPlanHtml();
    // Plan Ahead is only fully built for the "Build your plan" drill; in other
    // scenarios it shows the "this page doesn't register you" note instead.
    case 'planahead': return state.scen === 'planahead' ? planAheadHtml() : notRegisteringHtml();
    default:          return notRegisteringHtml();   // browse
  }
}

/* ---- Fit the page to the window -------------------------------------------------------
   The replica is laid out at BANNER_DESIGN_WIDTH and zoomed so it fills the
   window exactly, leaving room for the taskbar clock. */

function fitBanner() {
  const bw = document.getElementById('bw');
  if (!bw) return;
  const width = document.documentElement.clientWidth;
  const height = window.innerHeight - TASKBAR_HEIGHT;
  const zoom = width / BANNER_DESIGN_WIDTH;
  bw.style.zoom = zoom;
  bw.style.height = (height / zoom) + 'px';
}

/* ---- Notifications ------------------------------------------------------------------------ */

function renderNotes() {
  const box = qs('#bw-notes');
  if (!box) return;
  const count = qs('#bw-count');
  if (count) {
    count.textContent = state.notes.length;
    count.hidden = !state.notes.length;
  }
  box.innerHTML = state.notes.map((n) => `
    <div class="note ${n.kind}" role="${n.kind === 'err' ? 'alert' : 'status'}">
      <button class="x" data-act="note-close" data-id="${n.id}" aria-label="Dismiss">×</button>
      <b>${escapeHtml(n.title)}</b>
      ${n.lines.length ? `<ul>${n.lines.map((l) => `<li>${escapeHtml(l)}</li>`).join('')}</ul>` : ''}
    </div>`).join('');
}

/* ---- Clocks (trainer bar + taskbar), updated by tick() --------------------------------- */

function updateClockReadouts() {
  const clock = qs('#hud-clock');
  if (!clock) return;
  const now = formatClock(simNow());
  clock.textContent = now;
  const taskbar = qs('#tb-clock');
  if (taskbar) taskbar.textContent = now;
  qs('#hud-el').textContent = isOpen() ? formatDuration(elapsedSeconds()) : 'waiting';
  const flag = qs('#hud-flag');
  if (flag) {
    flag.className = 'open-flag ' + (isOpen() ? 'yes' : 'no');
    flag.textContent = isOpen() ? 'OPEN' : 'NOT OPEN';
  }
  qs('#hud-mis').textContent = state.mistakes.length;
}

function taskbarHtml() {
  return `
    <div class="taskbar" aria-label="Clock">
      <div class="tb-time"><span id="tb-clock">${formatClock(simNow())}</span><span>${state.dateLabel}</span></div>
    </div>`;
}
