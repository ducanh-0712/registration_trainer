/* =============================================================================
   storage.js — run history, kept in this browser's localStorage.

   Storage can be unavailable (private windows, blocked site data), so every
   read and write is wrapped and the trainer keeps working without it.
   ========================================================================== */
"use strict";

function readStored(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (err) {
    return fallback;
  }
}

function writeStored(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    /* storage blocked: history just won't persist */
  }
}

/**
 * Past runs, newest first. Each entry: { d, mode, scen, t, mis, err, hints, grade }
 *   d = ISO date, t = seconds, mis = mistakes, err = submits that returned errors.
 * (Named runHistory, not `history`, so it doesn't shadow window.history.)
 */
let runHistory = readStored(STORAGE_KEYS.history, []);

function saveRunToHistory(entry) {
  runHistory.unshift(entry);
  runHistory = runHistory.slice(0, HISTORY_LIMIT);
  writeStored(STORAGE_KEYS.history, runHistory);
}
