/* =============================================================================
   events.js — listens to the page and routes events.

   One listener per event type on `document` (event delegation), because the
   page is redrawn all the time and individual buttons don't survive.
     click    → data-act buttons
     change   → data-chg selects and checkboxes (instant, no server delay)
     input    → text boxes (updated without redrawing, so typing isn't interrupted)
     keydown  → Esc, Enter, and the Ctrl+Alt+C / Ctrl+Alt+V panel shortcuts
   ========================================================================== */
"use strict";

/* ---- Clicks ------------------------------------------------------------------------------- */

/** Actions that work even when a run is finished (results window) or on the start screen. */
function handleTrainerClick(action, el) {
  switch (action) {
    case 'start':
      startRun(START.mode, START.scenario, { startBeforeOpen: START.startBeforeOpen, rush: START.rush });
      return true;
    case 'quit':
      if (!state) return true;
      currentView = 'start';
      state = null;
      clearInterval(clockTimer);
      render();
      window.scrollTo(0, 0);
      return true;
    case 'restart':
      if (state) startRun(state.mode, state.surprise ? 'random' : state.scen, state.opts);
      return true;
    case 'note-close':
      if (state) {
        state.notes = state.notes.filter((n) => n.id !== +el.dataset.id);
        renderNotes();
      }
      return true;
    case 'hint':
      if (!state || state.done) return true;
      state.hints++;
      state.penalty += 5;
      hintVisibleUntil = Date.now() + 7000;
      log('Used a hint (+5 s)');
      renderHint();
      setTimeout(() => { if (state && !state.done) renderHint(); }, 7100);
      return true;
  }
  return false;
}

document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const action = el.dataset.act;
  if (handleTrainerClick(action, el)) return;
  performAction(action, el);
});

/* ---- Selects and checkboxes ---------------------------------------------------------------- */

document.addEventListener('change', (e) => {
  const el = e.target;
  const kind = el.dataset.chg;
  if (!kind || !state || state.done) return;

  switch (kind) {
    case 'term':      state.termSel = el.value; break;
    case 'prep-term': state.prep.term = el.value; break;
    case 'fra':
      // Ticking the box opens the agreement; it only stays ticked after "I Accept".
      if (el.checked) state.prep.fraModal = true;
      else state.prep.fraChecked = false;
      break;
    case 'cond':      state.cond = el.checked; break;
    case 'panel':     state.panels[el.dataset.v] = el.checked; break;
    case 'per':       state.per = +el.value; break;
    case 'row-act': {
      const r = summaryRow(el.dataset.crn);
      if (r) r.action = el.value;
      break;
    }
    case 'pa-act': {
      const pa = state.planAhead;
      const row = pa.draft.find((x) => x.crn === el.dataset.crn);
      if (!row) break;
      // Removing a Pending class takes it out at once; a Planned one waits for Save Plan.
      if (el.value === 'remove' && row.status === 'pending') pa.draft = pa.draft.filter((x) => x !== row);
      else row.action = el.value;
      break;
    }
  }
  renderRun();
});

/* ---- Typing --------------------------------------------------------------------------------- */

/** Replace just the Subject drop-down list (a full redraw would steal focus from the input). */
function redrawSubjectList(input) {
  const box = input.parentElement;
  const old = box.querySelector('.s2-list');
  if (old) old.remove();
  box.insertAdjacentHTML('beforeend', subjectListHtml());
}

document.addEventListener('input', (e) => {
  const el = e.target;
  if (!state || state.done) return;

  if (el.dataset.paName) {                      // Name Your Plan box
    state.planAhead.nameVal = el.value;
    renderHint();
    return;
  }
  if (el.dataset.inp) {                         // Find Classes fields
    state.find[el.dataset.inp] = el.value;
    if (el.dataset.inp === 'subj') {
      state.find.open = true;
      redrawSubjectList(el);
    }
    renderHint();
    return;
  }
  if (el.dataset.crnI !== undefined) {          // Enter CRNs boxes: digits only, live lookup
    const i = +el.dataset.crnI;
    state.crnInputs[i] = el.value.replace(/\D/g, '').slice(0, 5);
    if (el.value !== state.crnInputs[i]) el.value = state.crnInputs[i];
    const lookup = qs('#crn-t-' + i);
    if (lookup) lookup.innerHTML = crnLookupHtml(state.crnInputs[i]);
    renderHint();
  }
});

/* ---- Subject picker open/close ---------------------------------------------------------------- */

document.addEventListener('focusin', (e) => {
  if (state && !state.done && e.target.id === 'f-subj' && !state.find.open) {
    state.find.open = true;
    e.target.parentElement.insertAdjacentHTML('beforeend', subjectListHtml());
  }
});

document.addEventListener('mousedown', (e) => {
  if (state && state.find && state.find.open && !e.target.closest('.s2')) {
    state.find.open = false;
    const list = qs('.s2-list');
    if (list) list.remove();
  }
});

/* ---- Keyboard ----------------------------------------------------------------------------------- */

document.addEventListener('keydown', (e) => {
  if (!state || currentView !== 'run') return;
  const el = e.target;

  // Esc closes a dialog first; otherwise shows/hides the trainer bar.
  if (e.key === 'Escape') {
    if (state.details) { state.details = null; renderRun(); return; }
    if (state.planAhead.modal) { state.planAhead.modal = false; renderRun(); return; }
    toggleTrainerBar();
    return;
  }
  if (state.done) return;

  // Panel shortcuts shown in the blue tip bubble.
  if (e.ctrlKey && e.altKey && e.key.toLowerCase() === 'c') {
    e.preventDefault();
    Object.assign(state, { panels: defaultPanels(), split: 'mid', panelsMenu: false });
    renderRun();
    return;
  }
  if (e.ctrlKey && e.altKey && e.key.toLowerCase() === 'v') {
    e.preventDefault();
    state.panelsMenu = !state.panelsMenu;
    renderRun();
    return;
  }

  if (e.key !== 'Enter' || !el.dataset) return;
  if (el.dataset.paName) {                      // Enter in Name Your Plan = Save
    e.preventDefault();
    performAction('plan-save', el);
  } else if (el.dataset.inp === 'subj') {       // Enter in Subject = pick the top match
    e.preventDefault();
    const first = qs('.s2-opt');
    state.find.subj = resolveSubject(state.find.subj) || (first && first.dataset.v) || '';
    state.find.open = false;
    renderRun();
    const num = qs('#f-num');
    if (num) num.focus();
  } else if (el.dataset.inp) {                  // Enter in Course Number / Keyword = Search
    e.preventDefault();
    performAction('find-search', el);
  } else if (el.dataset.crnI !== undefined) {   // Enter in a CRN box = Add to Summary
    e.preventDefault();
    performAction('crn-add', el);
  }
});

/* ---- Window and badge ------------------------------------------------------------------------------- */

window.addEventListener('resize', () => { if (currentView === 'run' && state) fitBanner(); });

/** Double-clicking the PRACTICE badge also toggles the trainer bar (handy without a keyboard). */
document.addEventListener('dblclick', (e) => {
  if (state && currentView === 'run' && e.target.closest('.bw-logo')) toggleTrainerBar();
});
