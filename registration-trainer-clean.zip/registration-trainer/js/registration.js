/* =============================================================================
   registration.js — the rules of the Summary panel and Submit.

   A Summary row looks like { crn, status, action, msg, wl } where
     status: pending | registered | waitlisted | dropped | error
     action: register | remove | waitlist | drop | none
   Nothing is registered until Submit; Submit then checks each add the way
   Banner does (prerequisite, seats, duplicate, time conflict, max hours).
   ========================================================================== */
"use strict";

/* ---- Summary helpers ------------------------------------------------------------- */

const summaryRow = (crn) => state.summary.find((r) => r.crn === crn);
const seatsLeft = (s) => s.cap - s.enrolled;
const canWaitlist = (s) => seatsLeft(s) <= 0 && s.waitCap > 0 && s.waitCount < s.waitCap;

/** Rows that will count once submitted (used to avoid suggesting clashing sections). */
function activeRows() {
  return state.summary.filter((r) =>
    (r.status === 'registered' && r.action !== 'drop') ||
    (r.status === 'pending' && r.action === 'register') ||
    r.status === 'waitlisted');
}

/** Is there anything for Submit to do? (Submit is greyed out otherwise.) */
function hasChanges() {
  return state.summary.some((r) =>
    r.status === 'pending' || r.status === 'error' ||
    r.action === 'drop' || r.action === 'remove' || r.action === 'waitlist');
}

function statusText(r) {
  return { pending: 'Pending', registered: 'Registered', waitlisted: 'Waitlisted', dropped: 'Dropped' }[r.status]
    || 'Errors Preventing Registration';
}

/** Put a section in the Summary as Pending. `how` is recorded in the timeline. */
function addToSummary(crn, how) {
  const s = state.byCrn[crn];
  if (!s) return false;
  const r = summaryRow(crn);
  if (r && r.status === 'dropped') {
    Object.assign(r, { status: 'pending', action: 'register', msg: '' });
    if (how) log(`Re-added ${courseKey(s)} ${s.sec} (CRN ${crn}) via ${how}`);
    return true;
  }
  if (r) {
    notify('info', `CRN ${crn} is already in your Summary.`);
    return false;
  }
  state.summary.push({ crn, status: 'pending', action: 'register', msg: '' });
  if (how) log(`Added ${courseKey(s)} ${s.sec} (CRN ${crn}) to Summary via ${how}`);
  return true;
}

/* ---- Submit -------------------------------------------------------------------------- */

/**
 * Why adding section `s` would fail, or null if it succeeds.
 * Checks run in Banner's order: prerequisite, seats, duplicate, time conflict, max hours.
 * @param {object}   s               the section being added
 * @param {object[]} registeredSoFar sections you'd hold after this Submit's earlier adds and drops
 * @param {number}   hours           units already held
 * @returns {{msg: string, wl?: boolean, clash?: object} | null}  wl = waitlist is possible
 */
function addError(s, registeredSoFar, hours) {
  if (s.prereq) return { msg: 'Must have the required prerequisite(s).' };
  if (seatsLeft(s) <= 0) {
    return canWaitlist(s)
      ? { msg: `Closed - ${s.waitCount} Waitlisted`, wl: true }
      : { msg: 'Closed Section' };
  }
  const dup = registeredSoFar.find((o) => courseKey(o) === courseKey(s));
  if (dup) return { msg: 'Duplicate Course with Section ' + dup.crn };
  const clash = registeredSoFar.find((o) => overlaps(o, s));
  if (clash) return { msg: 'Time conflict with CRN ' + clash.crn, clash };
  if (hours + unitsOf(s) > MAX_HOURS) return { msg: 'Maximum hours exceeded' };
  return null;
}

/**
 * Submit: process every pending change in the Summary at once, like the real
 * page. Order: removes → adds → waitlists → mark adds registered → drops.
 * Failed adds stay in the Summary as errors with Action = Remove, so the next
 * Submit clears them.
 */
function doSubmit() {
  state.submits++;
  const { summary, byCrn, targets } = state;

  const removes = summary.filter((r) => r.action === 'remove');
  const adds = summary.filter((r) => (r.status === 'pending' || r.status === 'error') && r.action === 'register');
  const waitlists = summary.filter((r) => (r.status === 'error' || r.status === 'pending') && r.action === 'waitlist');
  const drops = summary.filter((r) => (r.status === 'registered' || r.status === 'waitlisted') && r.action === 'drop');

  if (!adds.length && !waitlists.length && !drops.length && !removes.length) {
    notify('info', 'Nothing to submit', ['There are no pending changes in your Summary.']);
    log('Submit with nothing pending');
    return;
  }

  // 1. Removes never reach the server; they just leave the Summary.
  state.summary = summary.filter((r) => r.action !== 'remove');

  // 2. Check each add against what you'd have after the drops.
  const dropping = new Set(drops.map((r) => r.crn));
  const kept = state.summary.filter((r) => r.status === 'registered' && !dropping.has(r.crn)).map((r) => byCrn[r.crn]);
  let hours = kept.reduce((sum, s) => sum + unitsOf(s), 0);
  const errors = [];
  const okAdds = [];

  adds.forEach((r) => {
    const s = byCrn[r.crn];
    const problem = addError(s, kept.concat(okAdds.map((c) => byCrn[c])), hours);
    if (!problem) {
      okAdds.push(s.crn);
      hours += unitsOf(s);
      return;
    }
    state.failed.add(s.crn);
    Object.assign(r, { status: 'error', action: 'remove', msg: problem.msg, wl: !!problem.wl });
    errors.push(`${courseKey(s)} CRN ${s.crn}: ${problem.msg}`);

    if (problem.clash) mistake(`Added ${courseKey(s)} ${s.sec}, which overlaps CRN ${problem.clash.crn}. Check the Schedule panel before you submit.`);
    if (problem.msg.startsWith('Duplicate')) mistake(`Tried to add a second section of ${courseKey(s)} without dropping the first.`);
    if (problem.msg.startsWith('Closed') && targets.rush !== undefined && state.plan[targets.rush].baseCrn === s.crn) {
      mistake(`Too slow: ${courseKey(s)} filled at 7:00:45 while you were still working.`);
    }
  });

  // 3. Waitlist requests.
  waitlists.forEach((r) => {
    const s = byCrn[r.crn];
    if (s.waitCap > 0 && s.waitCount < s.waitCap) {
      s.waitCount++;
      Object.assign(r, { status: 'waitlisted', action: 'none', msg: '' });
      log(`Waitlisted ${courseKey(s)} (position ${s.waitCount})`);
    } else {
      errors.push(`CRN ${s.crn}: Waitlist is full`);
    }
  });

  // 4. Successful adds become Registered.
  okAdds.forEach((crn) => {
    const r = summaryRow(crn);
    const s = byCrn[crn];
    Object.assign(r, { status: 'registered', action: 'none', msg: '' });
    s.enrolled++;
    log(`Registered ${courseKey(s)} ${s.sec} (CRN ${crn})`);
  });

  // 5. Drops. With Conditional Add and Drop on, a failed add cancels every drop.
  if (drops.length) {
    const blocked = state.cond && errors.length > 0 && adds.length > 0;
    if (blocked) {
      drops.forEach((r) => { r.action = 'none'; });
      errors.push('Conditional Add and Drop: your drops were not processed because an add failed.');
    } else {
      if (!state.cond && adds.length && state.scen === 'swap') {
        mistake('Dropped without Conditional Add and Drop. If the add had failed, you would have lost your seat.');
      }
      drops.forEach((r) => {
        const s = byCrn[r.crn];
        if (r.status === 'waitlisted') s.waitCount--; else s.enrolled--;
        Object.assign(r, { status: 'dropped', action: 'none' });
        log(`Dropped ${courseKey(s)} ${s.sec} (CRN ${r.crn})`);
      });
    }
  }

  // 6. The real page stacks a green "Save Successful" over one red line per failed CRN.
  errors.slice().reverse().forEach((e) => notify('err', e));
  if (errors.length) {
    state.errorsHit++;
    log(`Submit returned ${errors.length} error(s)`);
  }
  notify('ok', 'Save Successful');

  if (registrationGoalMet()) finishRun();
}

/* ---- Is the run finished? ------------------------------------------------------------- */

/**
 * Has the registration goal been reached? Every plan course must be Registered
 * (any section counts), except: the prerequisite course (which can't be) must be
 * cleared from the Summary, and the waitlist course may be Waitlisted instead.
 * The swap scenario only needs the new section in and the old one out.
 */
function registrationGoalMet() {
  const { targets, summary, byCrn } = state;
  if (state.scen === 'swap') {
    const fresh = summaryRow(targets.swapNew);
    const old = summaryRow(targets.swapOld);
    return fresh && fresh.status === 'registered' && !(old && old.status === 'registered');
  }
  if (state.scen === 'planahead') return false;
  // The prerequisite error has to be cleared from the Summary too.
  if (targets.prereq !== undefined && summary.some((r) => r.status === 'error')) return false;

  return state.plan.every((p, i) => i === targets.prereq || summary.some((r) => {
    const s = byCrn[r.crn];
    return courseKey(s) === courseKey(p) &&
      (r.status === 'registered' || (i === targets.wait && r.status === 'waitlisted'));
  }));
}

/** Build-your-plan drill: saved, and every planned course is in it. */
function planGoalMet() {
  const P = state.planAhead;
  if (!P.saved) return false;
  return state.plan.every((p) => P.draft.some((d) =>
    d.crn === (p.crn || p.baseCrn) || courseKey(state.byCrn[d.crn]) === courseKey(p)));
}

/** Stop the clock, grade the run, save it, and show results a moment later. */
function finishRun() {
  state.done = true;
  state.endReal = Date.now();

  // Grade: Ready = within target with no mistakes; Close = within 2× target and at most one mistake.
  const t = elapsedSeconds();
  const target = SCENARIOS[state.scen].target;
  const misses = state.mistakes.length;
  const grade = (t <= target && misses === 0) ? 'ready'
    : (t <= target * 2 && misses <= 1) ? 'close'
    : 'practice';
  state.result = { t, grade };

  saveRunToHistory({
    d: new Date().toISOString(), mode: state.mode, scen: state.scen,
    t: +t.toFixed(1), mis: misses, err: state.errorsHit, hints: state.hints, grade,
  });
  log('All set. Registration complete.');

  // Leave the "Registered" statuses on screen briefly before the results cover them.
  setTimeout(() => {
    if (state && state.done) {
      state.showResults = true;
      renderResults();
    }
  }, 900);
}
