/* =============================================================================
   state.js — the state of one practice run, its clock, and how a run starts.

   `state` is null on the start screen. During a run it holds everything the
   screens need: which page is open, the Summary rows, the fake course
   catalogue, the clock, and the score.
   ========================================================================== */
"use strict";

/** The current run, or null on the start screen. */
let state = null;

/** 'start' (the Start/Your runs screen) or 'run'. */
let currentView = 'start';

/** setInterval handle for the 5×/second clock tick. */
let clockTimer = null;

/** While Date.now() is below this, the hint box is shown in timed mode. */
let hintVisibleUntil = 0;

/* ---- Practice clock ---------------------------------------------------------
   The run has its own clock: it starts at `clockBase` (seconds after midnight)
   when the run begins and then follows real time. */

/** Practice time right now, in seconds after midnight. */
function simNow() {
  return state.clockBase + (Date.now() - state.startReal) / 1000;
}

/** Has the 7:00 time ticket opened? */
function isOpen() {
  return simNow() >= TIME_TICKET_OPENS;
}

/** Real timestamp (ms) at which the practice clock reaches 7:00:00. */
function realOpenMs() {
  return state.startReal + Math.max(0, TIME_TICKET_OPENS - state.clockBase) * 1000;
}

/** Seconds since registration opened (or since the run began, if later), plus hint penalties. */
function elapsedSeconds() {
  const from = Math.max(state.startReal, realOpenMs());
  const end = state.endReal || Date.now();
  return Math.max(0, (end - from) / 1000) + state.penalty;
}

/** Practice-clock time to stamp on timeline entries. */
function stampTime() {
  return state.clockBase + ((state.endReal || Date.now()) - state.startReal) / 1000;
}

/* ---- Run log, mistakes and notifications ---------------------------------------
   log()     → the Timeline shown in the results window
   mistake() → counted against your grade (and also logged)
   notify()  → the coloured messages in the page's top-right corner */

function log(message) {
  state.log.push({ t: formatClock(stampTime()).replace(/ (AM|PM)$/, ''), msg: message });
}

function mistake(message) {
  state.mistakes.push(message);
  log('Mistake: ' + message);
}

/**
 * Show a message. kind: 'ok' (green), 'err' (red, stays until closed), 'info' (blue).
 * Green and blue messages fade after 4.5 s; at most four are shown.
 */
function notify(kind, title, lines = []) {
  const id = ++state.noteId;
  state.notes.unshift({ id, kind, title, lines });
  if (state.notes.length > 4) state.notes.length = 4;
  if (kind !== 'err') {
    setTimeout(() => {
      if (!state) return;
      state.notes = state.notes.filter((n) => n.id !== id);
      renderNotes();
    }, 4500);
  }
}

/* ---- Small state factories (used when a run starts and when things reset) ------- */

/** A blank Find Classes form. */
const emptySearch = () => ({ subj: '', num: '', kw: '', results: null, open: false, err: false });

/** All three panels showing — also what Ctrl+Alt+C resets to. */
const defaultPanels = () => ({ upper: true, sched: true, summary: true });

/** Turn what was typed in Subject ("math", "Mathematics", "MATH") into a subject code, or ''. */
function resolveSubject(text) {
  text = (text || '').trim();
  if (!text) return '';
  const upper = text.toUpperCase();
  if (state && state.sections.some((s) => s.subj === upper)) return upper;
  const byName = Object.keys(SUBJECT_NAMES).find((k) => SUBJECT_NAMES[k].toLowerCase() === text.toLowerCase());
  return byName || (SUBJECT_NAMES[upper] ? upper : '');
}

/* ---- Fake course catalogue ----------------------------------------------------
   Each planned course gets three sections:
     plan     — the section you saved (its real CRN)
     alt      — an open section at a time that clashes with nothing else
     conflict — a section that overlaps another of your classes (a trap)   */

/** First meeting slot that clashes with none of `others`, preferring p's own pattern. */
function freeSlot(p, others) {
  const own = p.days.length >= 3 ? 'MWF' : 'TR';
  const patterns = [own, own === 'MWF' ? 'TR' : 'MWF'];
  for (const pattern of patterns) {
    for (const [start, end] of TIME_SLOTS[pattern]) {
      const slot = { days: pattern, start, end };
      if (slot.start === p.start && slot.days === p.days) continue;
      if (!others.some((o) => overlaps(slot, o))) return slot;
    }
  }
  return { days: p.days, start: p.start, end: p.end };
}

/** The next `n` section numbers ("01", "02", …) that aren't `taken`. */
function nextSectionNumbers(taken, n) {
  const out = [];
  for (let k = 1; out.length < n; k++) {
    const s = String(k).padStart(2, '0');
    if (s !== taken) out.push(s);
  }
  return out;
}

/**
 * Build the fake catalogue: plan/alt/conflict sections for every planned course.
 * Also sets p.baseCrn on each plan item (its real CRN, or an invented one when
 * the course was saved without a section), so scenarios can find "your" section.
 * @returns {{sections: object[], byCrn: Object<string, object>}}
 */
function buildCatalogue(plan) {
  const usedCrns = new Set(plan.map((p) => p.crn).filter(Boolean));
  const newCrn = () => {
    let c;
    do { c = String(20000 + randomInt(9000)); } while (usedCrns.has(c));
    usedCrns.add(c);
    return c;
  };

  const sections = [];
  const altSlots = [];
  plan.forEach((p, i) => {
    p.baseCrn = p.crn || newCrn();
    sections.push({ ...p, crn: p.baseCrn, cap: 30, enrolled: 16 + randomInt(9), waitCap: 0, waitCount: 0, kind: 'plan', idx: i });

    const others = plan.filter((_, j) => j !== i);
    const [altSec, conflictSec] = nextSectionNumbers(p.sec || '01', 2);

    const slot = freeSlot(p, others.concat(altSlots));
    altSlots.push(slot);
    sections.push({ ...p, crn: newCrn(), sec: altSec, ...slot, cap: 30, enrolled: 19 + randomInt(7), waitCap: 0, waitCount: 0, kind: 'alt', idx: i, instr: 'Staff' });

    if (others.length) {
      const o = others[randomInt(others.length)];
      sections.push({ ...p, crn: newCrn(), sec: conflictSec, days: o.days, start: o.start, end: o.end, cap: 30, enrolled: 14 + randomInt(10), waitCap: 0, waitCount: 0, kind: 'conflict', idx: i, instr: 'Staff' });
    }
  });

  sections.sort((a, b) => (a.subj + a.num + a.sec).localeCompare(b.subj + b.num + b.sec));
  const byCrn = {};
  sections.forEach((s) => { byCrn[s.crn] = s; });
  return { sections, byCrn };
}

/* ---- Starting a run ----------------------------------------------------------- */

/**
 * Start a new run.
 * @param {'timed'|'guided'} mode
 * @param {string} scenarioKey  key of SCENARIOS, or 'random'
 * @param {{startBeforeOpen?:boolean, rush?:boolean}} opts
 */
function startRun(mode, scenarioKey, opts) {
  let surprise = false;
  if (scenarioKey === 'random') {
    scenarioKey = shuffle(RANDOM_POOL)[0];
    surprise = true;
  }
  if (scenarioKey === 'gauntlet' && MY_PLAN.length < 2) scenarioKey = 'closed';

  // Normalise the plan so later code can trust its shape.
  const plan = MY_PLAN.map((p) => ({
    ...p,
    subj: p.subj.toUpperCase(),
    days: p.days.toUpperCase(),
    title: p.title || `${p.subj.toUpperCase()} ${p.num}`,
    instr: p.instr || 'Staff',
  }));
  const { sections, byCrn } = buildCatalogue(plan);
  const planItems = plan.map((p, i) => ({ ...p, crn: p.crn || null, idx: i }));

  // Scenarios set in open registration (later in November) skip the 7:00 wait.
  const later = ['waitlist', 'swap', 'planahead'].includes(scenarioKey);

  state = {
    mode, scen: scenarioKey, surprise, opts,
    sections, byCrn, plan: planItems,
    targets: {},                // which plan items a scenario breaks (closed, nocrn, wait, …)

    // Where you are
    screen: 'home',             // home | landing | term | prep | register | selplan | planahead | browse | info
    termMode: 'register',       // the Select a Term page leads to 'register' or 'plan'
    termSel: '',
    tab: 'find',                // upper tab on Register for Classes: find | crn | plans | sched
    lowTab: 'sched',            // lower-left tab: sched | details
    panels: defaultPanels(),    // which of the three panels are switched on
    split: 'mid',               // splitter: up | mid | down
    panelsMenu: false,
    planOpen: true,             // the plan row in the Plans tab is expanded
    tipHidden: false,           // the keyboard-shortcut bubble
    per: 10,                    // search results per page
    details: null,              // { crn, tab } while Class Details is open
    calScroll: null,            // calendar scroll position, kept across redraws

    // Trainer overlay
    bar: false,                 // the trainer bar (Esc) is showing
    escTipShown: false,         // the one-time "Press Esc" toast has been shown

    // Pre-registration
    agreementAccepted: true,
    agreementErrorShown: false, // the "agreement not accepted" mistake is only counted once
    prep: { term: '', stage: 'select', tuitionModal: false, fraChecked: false, fraModal: false },

    // Register for Classes
    summary: [],                // rows: { crn, status, action, msg, wl } — see registration.js
    cond: false,                // Conditional Add and Drop
    crnInputs: [''],
    find: emptySearch(),

    // Plan Ahead (Build your plan drill). draft rows: { crn, status: pending|planned, action }
    planAhead: { draft: [], saved: false, name: '', modal: false, nameVal: '' },

    // Messages and scoring
    notes: [], noteId: 0, log: [], mistakes: [],
    errorsHit: 0, submits: 0, hints: 0, penalty: 0,
    usedAddAll: false, singleAdds: 0, earlyTries: 0,
    failed: new Set(),          // CRNs that came back with an error at least once

    // Clock. Open-registration scenarios start at 10:14 AM on a later date.
    clockBase: later ? 10 * 3600 + 14 * 60 : (opts.startBeforeOpen ? TIME_TICKET_OPENS - 10 : TIME_TICKET_OPENS),
    dateLabel: later ? '11/30/2026' : '11/12/2026',
    startReal: Date.now(), endReal: 0, lastDrift: Date.now(),
    done: false,                // run finished (clock stopped, input ignored)
    busy: false,                // a fake server request is in flight
    rushFired: false,

    // Set by finishRun()
    result: null,               // { t, grade }
    showResults: false,
  };

  applyScenario(scenarioKey, mode, opts, later);
  log('Run started: ' + SCENARIOS[scenarioKey].name + (mode === 'guided' ? ' (guided)' : ' (timed)'));

  currentView = 'run';
  clearInterval(clockTimer);
  clockTimer = setInterval(tick, 200);
  render();
}

/**
 * Break the plan in whatever way the scenario calls for. Records which plan
 * items are affected in state.targets (indexes into state.plan), which the
 * hints, grading and result tips read back later.
 */
function applyScenario(key, mode, opts, later) {
  const { plan, byCrn, sections, targets } = state;
  const order = shuffle(plan.map((_, i) => i)); // pick different courses for each problem

  if (key === 'hold' || key === 'gauntlet') state.agreementAccepted = false;

  if (key === 'closed' || key === 'gauntlet') {
    targets.closed = order.shift();
    const s = byCrn[plan[targets.closed].baseCrn];
    s.enrolled = s.cap;
  }
  if (key === 'nocrn' || key === 'gauntlet') {
    targets.nocrn = order.shift();
    plan[targets.nocrn].crn = null;
  }
  if (key === 'waitlist') {
    targets.wait = order.shift();
    const s = byCrn[plan[targets.wait].baseCrn];
    s.enrolled = s.cap; s.waitCap = 10; s.waitCount = 3;
  }
  if (key === 'swap') {
    targets.swap = order.shift();
    plan.forEach((p) => state.summary.push({ crn: p.baseCrn, status: 'registered', action: 'none' }));
    const alt = sections.find((s) => s.idx === targets.swap && s.kind === 'alt');
    targets.swapOld = plan[targets.swap].baseCrn;
    targets.swapNew = alt.crn;
  }
  if (key === 'prereq') {
    targets.prereq = order.shift();
    const k = courseKey(plan[targets.prereq]);
    sections.forEach((s) => { if (courseKey(s) === k) s.prereq = true; });
  }
  if (plan.some((p) => !p.crn) && targets.nocrn === undefined) targets.nocrnUser = true;
  if (mode === 'timed' && opts.rush && !later && order.length) targets.rush = order.shift();
}

/* ---- Clock tick (5× a second) ---------------------------------------------------- */

function tick() {
  if (!state || currentView !== 'run') return;
  const now = simNow();

  if (!state.done) {
    // Rush option: another student takes your seat at 7:00:45.
    const { targets } = state;
    if (targets.rush !== undefined && !state.rushFired && now >= TIME_TICKET_OPENS + 45) {
      state.rushFired = true;
      const s = state.byCrn[state.plan[targets.rush].baseCrn];
      const mine = state.summary.find((r) => r.crn === s.crn && r.status === 'registered');
      if (!mine) {
        s.enrolled = s.cap;
        log(`Other students filled ${courseKey(s)} ${s.sec} (CRN ${s.crn}).`);
      }
    }
    // Seats slowly fill once registration is open, so counts feel alive.
    if (isOpen() && Date.now() - state.lastDrift > 2500) {
      state.lastDrift = Date.now();
      const pool = state.sections.filter((s) => s.cap - s.enrolled > 3);
      if (pool.length) pool[randomInt(pool.length)].enrolled++;
    }
  }

  updateClockReadouts();
  if (state.mode === 'guided' && !state.done) renderHint();
}
